Phantom Wallet virtual/social extension

This package does not install itself silently into Chrome. Chrome requires a user confirmation for unpacked extensions.

Windows:
1. Extract this ZIP.
2. Run INSTALL-WINDOWS.bat.
3. In Chrome, enable Developer mode, click Load unpacked, and select the folder opened by the helper.

macOS:
1. Extract this ZIP.
2. Right-click INSTALL-MAC.command and choose Open if macOS blocks it.
3. In Chrome, enable Developer mode, click Load unpacked, and select the folder opened by the helper.

The helper copies the extension to a stable application-data folder and opens chrome://extensions. It does not modify Chrome's protected internal extension directory.
