#!/bin/bash
set -e
DEST="$HOME/Library/Application Support/PhantomWalletVirtual/extension"
echo "Installing extension files to: $DEST"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -R "$(dirname "$0")/extension/." "$DEST/"
open -a "Google Chrome" "chrome://extensions/" 2>/dev/null || open "chrome://extensions/"
open "$DEST"
echo
echo "Chrome has been opened to Extensions."
echo "1. Turn on Developer mode."
echo "2. Click Load unpacked."
echo "3. Select the folder that just opened."
read -p "Press Enter to close..."
