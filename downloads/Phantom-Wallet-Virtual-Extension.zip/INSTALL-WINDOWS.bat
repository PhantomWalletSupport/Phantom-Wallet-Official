@echo off
setlocal
set "DEST=%LOCALAPPDATA%\PhantomWalletVirtual\extension"
echo Installing extension files to:
echo %DEST%
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
xcopy "%~dp0extension\*" "%DEST%\" /E /I /Y >nul
start "" chrome "chrome://extensions/"
start "" explorer "%DEST%"
echo.
echo Chrome has been opened to Extensions.
echo 1. Turn on Developer mode.
echo 2. Click Load unpacked.
echo 3. Select the folder that just opened.
pause
