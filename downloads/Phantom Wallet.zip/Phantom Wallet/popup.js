function formatCoinAmount(n){const v=Number(n)||0;return v.toLocaleString(undefined,{maximumFractionDigits:8})}
const $=id=>document.getElementById(id);
const API='https://api.coingecko.com/api/v3';
const LEDGER='https://acpqhhcxnskdomnyxgmg.supabase.co/functions/v1/larp-wallet-ledger';
const OWNER_API='https://acpqhhcxnskdomnyxgmg.supabase.co/functions/v1/larp-wallet-owner';
const AUTH_API='https://acpqhhcxnskdomnyxgmg.supabase.co/functions/v1/larp-wallet-auth';
const PREMIUM_API='https://acpqhhcxnskdomnyxgmg.supabase.co/functions/v1/larp-wallet-premium';
const USERNAME_API='https://acpqhhcxnskdomnyxgmg.supabase.co/functions/v1/larp-wallet-username';
let deviceId='';
let sharedReady=false;
let seenTransferIds=new Set();
const pendingBalancePushes=new Set();
const CORE={
  solana:{id:'solana',symbol:'SOL',name:'Solana',logo:'assets/sol.png',fallback:0},
  bitcoin:{id:'bitcoin',symbol:'BTC',name:'Bitcoin',logo:'assets/btc.png',fallback:0},
  ethereum:{id:'ethereum',symbol:'ETH',name:'Ethereum',logo:'assets/eth.png',fallback:0},
  'usd-coin':{id:'usd-coin',symbol:'USDC',name:'USDC',logo:'assets/usdc.png',fallback:1}
};
let coins={...CORE};
let market={};
let balances={};
let adminSession=false;
let premiumAccess=false;
let ownerSession=false;
let ownerToken='';
let ownerHeartbeatTimer=null;
let ownerViewUser='';
let ownerViewSnapshot=null;
const DEFAULT_ADMIN_PASSWORD_HASH='22b864edf9e2bf16591fad2085d5c8b8838d9f410b13a60bb28a4e9479afac14';
const OWNER_KEY_HASH='50e96bd9e370cd2d8fd8648dd84e5984f418340c3f77cc28c77feacf80c0d0c7';
let activity=[];
let prefs={hideBalances:false,accountName:'Account 1'};
let activeProfile='admin';
let activeUsername='';
let sessionUnlocked=false;
let profileSwitching=false;
let userAccounts={};
let initReady=Promise.resolve();
let marketPage=1;
let marketHasMore=true;
let marketLoading=false;
const fmtUSD=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:Math.abs(Number(n)||0)<1?6:2}).format(Number(n)||0);
const fmtAmt=(n,max=8)=>Number(n||0).toLocaleString('en-US',{maximumFractionDigits:max});
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const coin=id=>coins[id]||CORE[id]||{id,symbol:String(id).toUpperCase(),name:String(id),logo:'assets/sol.png'};
const price=id=>Number(market[id]?.price)||Number(coin(id).fallback)||0;
const change=id=>Number(market[id]?.change24)||0;
function imageFor(c){return esc(c.logo||c.image||'assets/sol.png')}
function normalizeMarket(x){return {id:x.id,symbol:String(x.symbol||'').toUpperCase(),name:x.name||x.id,logo:x.image||CORE[x.id]?.logo||'',rank:x.market_cap_rank??999999,price:Number(x.current_price)||0,change24:Number(x.price_change_percentage_24h)||0,high:Number(x.high_24h)||0,low:Number(x.low_24h)||0,marketCap:Number(x.market_cap)||0,volume:Number(x.total_volume)||0,sparkline:Array.isArray(x.sparkline_in_7d?.price)?x.sparkline_in_7d.price.map(Number).filter(Number.isFinite):[]}}
function remember(x){const c=normalizeMarket(x);coins[c.id]={...(coins[c.id]||{}),...c};market[c.id]={price:c.price,change24:c.change24,high:c.high,low:c.low,marketCap:c.marketCap,volume:c.volume,sparkline:c.sparkline||market[c.id]?.sparkline||[],updated:Date.now()};return coins[c.id]}
function toast(msg){let e=document.querySelector('.toast');if(!e){e=document.createElement('div');e.className='toast';document.body.appendChild(e)}e.textContent=msg;e.classList.add('show');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('show'),1500)}
function transferToast(kind,c,amount,detail=''){let e=document.querySelector('.receive-toast');if(!e){e=document.createElement('div');e.className='receive-toast';document.body.appendChild(e)}const incoming=kind==='Received'||kind==='Receiving',sign=incoming?'+':'−',usd=price(c.id)>0?fmtUSD(Math.abs(Number(amount)||0)*price(c.id)):'';const safeDetail=detail?esc(detail):'Completed';e.classList.remove('show','incoming','outgoing');void e.offsetWidth;e.classList.add(incoming?'incoming':'outgoing');e.innerHTML=`<div class="tx-glow"></div><div class="tx-rail"><span></span></div><div class="receive-toast-icon"><img src="${imageFor(c)}" alt=""></div><div class="receive-toast-copy"><div class="receive-toast-top"><strong>${esc(kind)}</strong><span>now</span></div><div class="receive-toast-amount">${sign}${fmtAmt(amount)} ${esc(c.symbol)}</div><div class="receive-toast-meta"><span>${usd?esc(usd):esc(c.name)}</span><span>${safeDetail}</span></div></div><div class="tx-status"><span></span></div>`;requestAnimationFrame(()=>e.classList.add('show'));clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('show'),3300)}
function showReceiveToast(c,amount,detail=''){transferToast('Received',c,amount,detail)}
function showSendToast(c,amount,detail=''){transferToast('Sent',c,amount,detail)}
async function ledger(action,payload={}){const r=await fetch(LEDGER,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,deviceId,...payload})});let d={};try{d=await r.json()}catch{}if(!r.ok||!d.ok)throw new Error(d.error||`Transfer service ${r.status}`);return d}
async function premiumApi(action,payload={}){
  const r=await fetch(PREMIUM_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,deviceId,username:activeUsername,...payload})});
  let d={};try{d=await r.json()}catch{}
  if(!r.ok||!d.ok)throw new Error(d.error||`Premium service ${r.status}`);
  return d;
}
async function refreshPremiumAccess(){
  if(activeProfile!=='user'||!activeUsername||!deviceId){premiumAccess=false;applyAccountAccess();return false}
  try{
    const d=await premiumApi('status');
    premiumAccess=!!d.premium;
  }catch(e){
    console.warn('premium status',e);
    premiumAccess=false;
  }
  applyAccountAccess();
  return premiumAccess;
}
function hasBuyAccess(){return adminSession||ownerSession||premiumAccess}
function hasResetAccess(){return adminSession||ownerSession||premiumAccess}
async function ownerApi(action,payload={}){
  const r=await fetch(OWNER_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,token:ownerToken,deviceId,username:activeUsername,...payload})});
  let d={};try{d=await r.json()}catch{}
  if(!r.ok||!d.ok)throw new Error(d.error||`Owner service ${r.status}`);
  return d;
}
async function authApi(action,payload={}){
  const r=await fetch(AUTH_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,...payload})});
  let d={};try{d=await r.json()}catch{}
  if(!r.ok||!d.ok)throw new Error(d.error||`Account service ${r.status}`);
  return d;
}

async function ownerHeartbeat(){
  if(!sessionUnlocked||!deviceId)return;
  const username=ownerSession?'owner':(activeProfile==='admin'?'admin':activeUsername);
  try{await fetch(OWNER_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'heartbeat',deviceId,username})})}catch{}
}
function startOwnerHeartbeat(){
  clearInterval(ownerHeartbeatTimer);
  ownerHeartbeat();
  ownerHeartbeatTimer=setInterval(ownerHeartbeat,30000);
}
function ensureOwnerBar(){
  let bar=$('ownerBar');
  if(!ownerSession){
    if(bar)bar.remove();
    return;
  }
  if(!bar){
    bar=document.createElement('button');
    bar.id='ownerBar';
    bar.type='button';
    bar.style.cssText='margin:0 10px 8px;width:calc(100% - 20px);height:42px;border:1px solid rgba(160,130,255,.35);border-radius:12px;background:#1b1823;color:#c9b8ff;display:flex;align-items:center;justify-content:space-between;padding:0 12px;font:600 12px Inter,system-ui;cursor:pointer';
    bar.innerHTML='<span>OWNER CONSOLE</span><span style="opacity:.65;font-weight:500">Users ›</span>';
    const banner=$('marketBanner');
    banner?.insertAdjacentElement('afterend',bar);
    bar.onclick=openOwnerUsers;
  }
}

function ensureOwnerViewBar(){
  let bar=$('ownerViewBar');
  if(!ownerSession||!ownerViewUser){
    if(bar)bar.remove();
    return;
  }
  if(!bar){
    bar=document.createElement('button');
    bar.id='ownerViewBar';
    bar.type='button';
    bar.style.cssText='margin:0 10px 8px;width:calc(100% - 20px);height:40px;border:1px solid rgba(160,130,255,.35);border-radius:10px;background:#17151d;color:#d5c8ff;display:flex;align-items:center;justify-content:space-between;padding:0 11px;font:600 11px Inter,system-ui;cursor:pointer';
    const banner=$('marketBanner');
    banner?.insertAdjacentElement('afterend',bar);
    bar.onclick=exitOwnerView;
  }
  bar.innerHTML=`<span>OWNER VIEW · ${esc(ownerViewUser)}</span><span style="opacity:.65;font-weight:500">Return ›</span>`;
}
async function enterOwnerView(username){
  if(!ownerSession)return;
  const key=String(username||'').trim().toLowerCase();
  let d=null,backendError=null;
  try{
    d=await ownerApi('wallet',{username:key});
  }catch(e){
    backendError=e;
  }

  // If the shared record is missing/incomplete, use the locally stored account
  // instead of making Owner View fail completely.
  if(!d){
    const stored=await chrome.storage.local.get('userAccounts');
    const accounts={...(stored.userAccounts||{}),...userAccounts};
    const local=accounts[key];
    if(!local)throw backendError||new Error('Account data not found');
    const lp=local.profile||{};
    d={
      user:{username:key,display_username:key,device_id:lp.deviceId||''},
      balances:Object.entries(lp.balances||{}).map(([coin_id,amount])=>({coin_id,symbol:coin(coin_id).symbol,amount:Number(amount)||0})),
      addresses:[],
      transfers:[]
    };
  }

  ownerViewUser=key;
  ownerViewSnapshot={
    activeUsername,
    deviceId,
    balances:{...balances},
    activity:[...activity],
    prefs:{...prefs}
  };

  activeUsername=key;
  deviceId=d.user?.device_id||deviceId;
  balances={};
  for(const b of (d.balances||[])) balances[b.coin_id]=Number(b.amount)||0;

  // Prefer locally saved activity when available; otherwise show server transfers.
  const stored=await chrome.storage.local.get('userAccounts');
  const local=(stored.userAccounts||{})[key];
  if(local?.profile?.activity?.length){
    activity=[...local.profile.activity];
  }else{
    activity=(d.transfers||[]).map(t=>({
      id:`owner-${t.id}`,
      type:t.sender_device_id===deviceId?'Sent':'Received',
      coinId:t.coin_id,
      symbol:t.symbol,
      amount:Number(t.amount)||0,
      timestamp:t.created_at
    }));
  }

  prefs={...(prefs||{}),accountName:d.user?.display_username||d.user?.username||key};
  document.querySelector('.account-name').textContent=prefs.accountName;

  closeSheet();
  renderHome();
  ensureOwnerViewBar();
  toast(backendError?`Viewing ${key} · local data`:`Viewing ${key}`);
}
function exitOwnerView(){
  if(!ownerSession||!ownerViewSnapshot)return;
  activeUsername=ownerViewSnapshot.activeUsername;
  deviceId=ownerViewSnapshot.deviceId;
  balances={...ownerViewSnapshot.balances};
  activity=[...ownerViewSnapshot.activity];
  prefs={...ownerViewSnapshot.prefs};
  ownerViewUser='';
  ownerViewSnapshot=null;
  document.querySelector('.account-name').textContent='Owner';
  renderHome();
  ensureOwnerViewBar();
  ensureOwnerBar();
  toast('Returned to Owner');
}
async function openOwnerUsers(){
  if(!ownerSession)return;
  openSheet('Owner console',`<div id="ownerUsers" class="asset-picker"><div class="account-card"><strong>Loading users…</strong><span>Checking active accounts</span></div></div>`);
  try{
    const d=await ownerApi('users');
    const users=d.users||[];
    $('ownerUsers').innerHTML=users.length?users.map(u=>{
      const seen=u.online?'Online':(u.last_seen?`Last seen ${new Date(u.last_seen).toLocaleString()}`:'Offline');
      return `<div class="menu-row" style="cursor:default"><span class="left"><strong>${esc(u.display_username||u.username)}</strong><small>${esc(seen)}</small></span><span style="display:flex;gap:6px"><button class="mini" data-owner-view="${esc(u.username)}" type="button">Open</button><button class="mini" data-owner-user="${esc(u.username)}" type="button">Manage</button></span></div>`;
    }).join(''):`<div class="account-card"><strong>No users yet</strong><span>Registered accounts will appear here.</span></div>`;
    document.querySelectorAll('[data-owner-view]').forEach(b=>b.onclick=async()=>{b.disabled=true;try{await enterOwnerView(b.dataset.ownerView)}catch(e){toast(e.message||'Could not open account');b.disabled=false}});
    document.querySelectorAll('[data-owner-user]').forEach(b=>b.onclick=()=>openOwnerWallet(b.dataset.ownerUser));
  }catch(e){$('ownerUsers').innerHTML=`<div class="account-card"><strong>Could not load users</strong><span>${esc(e.message||'Unknown error')}</span></div>`}
}
async function openOwnerWallet(username){
  if(!ownerSession)return;
  const key=String(username||'').trim().toLowerCase();
  openSheet(`Manage ${key}`,`<div id="ownerWalletView"><div class="account-card"><strong>Loading wallet…</strong><span>Fetching account data</span></div></div>`);
  try{
    let d=null;
    try{d=await ownerApi('wallet',{username:key})}catch{}
    const stored=await chrome.storage.local.get('userAccounts');
    const accounts={...(stored.userAccounts||{}),...userAccounts};
    const local=accounts[key];

    if(!d&&!local)throw new Error('Account data not found');

    const remoteBalances=d?.balances||[];
    const localBalances=local?.profile?.balances||{};
    const merged=new Map(remoteBalances.map(b=>[b.coin_id,{...b,amount:Number(b.amount)||0}]));
    for(const [coinId,amount] of Object.entries(localBalances)){
      if(!merged.has(coinId))merged.set(coinId,{coin_id:coinId,symbol:coin(coinId).symbol,amount:Number(amount)||0});
    }
    const walletBalances=[...merged.values()];
    const addresses=d?.addresses||[];
    const display=d?.user?.display_username||d?.user?.username||key;

    const rows=walletBalances.length
      ? walletBalances.map(b=>`<div class="menu-row"><span class="left"><strong>${esc(b.symbol)}</strong><small>${esc(b.coin_id)}</small></span><span class="value">${formatCoinAmount(Number(b.amount)||0)}</span></div>`).join('')
      : `<div class="account-card"><strong>No balances</strong><span>This account has no stored holdings yet.</span></div>`;

    const options=[...new Set([...Object.values(CORE).map(c=>c.id),...walletBalances.map(b=>b.coin_id)])]
      .map(id=>{const c=coin(id);return `<option value="${esc(id)}">${esc(c.name)} (${esc(c.symbol)})</option>`}).join('');

    const passwordControl=`<div class="field"><label>Reset password</label><input id="ownerNewPassword" type="password" autocomplete="new-password" placeholder="New password"></div><button id="ownerResetPassword" class="secondary">Reset password</button>`;

    $('ownerWalletView').innerHTML=`
      <div class="account-card"><strong>${esc(display)}</strong><span>${addresses.length} receiving addresses · ${walletBalances.length} balances</span></div>
      <button id="ownerOpenAccount" class="primary">Open account</button>
      <div class="menu-list">${rows}</div>
      <div class="field"><label>Asset</label><select id="ownerCoin">${options}</select></div>
      <div class="field"><label>Set balance</label><input id="ownerAmount" inputmode="decimal" placeholder="0"></div>
      <button id="ownerSetBalance" class="primary">Update wallet</button>
      ${passwordControl}
      <button id="ownerBackUsers" class="secondary">Back to users</button>`;

    $('ownerOpenAccount').onclick=async()=>{
      const btn=$('ownerOpenAccount');btn.disabled=true;btn.textContent='Opening…';
      try{await enterOwnerView(key)}catch(e){toast(e?.message||'Could not open account');btn.disabled=false;btn.textContent='Open account'}
    };

    $('ownerSetBalance').onclick=async()=>{
      const id=$('ownerCoin').value,c=coin(id),amount=Number($('ownerAmount').value);
      if(!Number.isFinite(amount)||amount<0)return toast('Enter a valid balance');
      const btn=$('ownerSetBalance');btn.disabled=true;btn.textContent='Updating…';
      try{
        // Update server data where available.
        try{await ownerApi('setBalance',{username:key,coinId:id,symbol:c.symbol,amount})}catch(e){if(!local)throw e}
        // Also update the local profile when this browser has the account.
        if(local){
          local.profile=local.profile||{};
          local.profile.balances={...(local.profile.balances||{}),[id]:amount};
          accounts[key]=local;
          userAccounts=accounts;
          await chrome.storage.local.set({userAccounts:accounts});
        }
        toast(`${key} updated`);
        openOwnerWallet(key);
      }catch(e){
        toast(e?.message||'Update failed');
        btn.disabled=false;btn.textContent='Update wallet';
      }
    };

    if($('ownerResetPassword')){
      $('ownerResetPassword').onclick=async()=>{
        const next=String($('ownerNewPassword').value||'');
        if(next.length<4)return toast('Use at least 4 characters');
        const btn=$('ownerResetPassword');btn.disabled=true;btn.textContent='Resetting…';
        try{
          const nextHash=await passwordDigest(next);
          await ownerApi('resetPassword',{username:key,passwordHash:nextHash});
          const fresh=await chrome.storage.local.get('userAccounts');
          const current={...(fresh.userAccounts||{}),...userAccounts};
          if(current[key]){
            current[key]={...current[key],passwordHash:nextHash};
            userAccounts=current;
            await chrome.storage.local.set({userAccounts:current});
          }
          $('ownerNewPassword').value='';
          toast(`Password reset for ${key}`);
          btn.disabled=false;btn.textContent='Reset password';
        }catch(e){
          toast(e?.message||'Could not reset password');
          btn.disabled=false;btn.textContent='Reset password';
        }
      };
    }

    $('ownerBackUsers').onclick=openOwnerUsers;
  }catch(e){
    $('ownerWalletView').innerHTML=`<div class="account-card"><strong>Could not load wallet</strong><span>${esc(e?.message||'Unknown error')}</span></div><button id="ownerBackUsers" class="secondary">Back to users</button>`;
    $('ownerBackUsers').onclick=openOwnerUsers;
  }
}


async function renameUsernameRemote(oldUsername,newUsername){
  const r=await fetch(USERNAME_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({deviceId,oldUsername,newUsername})});
  let d={};try{d=await r.json()}catch{}
  if(!r.ok||!d.ok)throw new Error(d.error||`Username service ${r.status}`);
  return d.username;
}
function newDeviceId(){const a=new Uint8Array(32);crypto.getRandomValues(a);return Array.from(a,b=>b.toString(16).padStart(2,'0')).join('')}
async function sharedAddress(id){const c=coin(id);const d=await ledger('address',{coinId:id,symbol:c.symbol});return d.address}
async function pushSharedBalances(ids){
  if(!sharedReady)return;
  const unique=[...new Set((ids||[]).filter(Boolean))];
  if(!unique.length)return;
  unique.forEach(id=>pendingBalancePushes.add(id));
  try{
    const payload={};
    for(const id of unique){payload[id]={amount:Math.max(0,Number(balances[id])||0),symbol:coin(id).symbol}}
    const d=await ledger('syncBalances',{balances:payload});
    for(const x of d.balances||[]){if(unique.includes(x.coin_id))balances[x.coin_id]=Number(x.amount)||0}
    await persist(false);
  }finally{
    unique.forEach(id=>pendingBalancePushes.delete(id));
  }
}
async function syncSharedState(showIncoming=true){if(!sessionUnlocked||profileSwitching||!sharedReady||!deviceId)return;try{const d=await ledger('state');let changed=false;for(const x of d.balances||[]){if(pendingBalancePushes.has(x.coin_id))continue;const n=Number(x.amount)||0;if((Number(balances[x.coin_id])||0)!==n){balances[x.coin_id]=n;changed=true}}const txs=d.transfers||[];for(const tx of txs){if(seenTransferIds.has(tx.id))continue;seenTransferIds.add(tx.id);if(tx.recipient_device_id===deviceId){const c=coin(tx.coin_id);if(showIncoming){showReceiveToast(c,Number(tx.amount),`From ${String(tx.sender_device_id).slice(0,6)}…${String(tx.sender_device_id).slice(-4)}`);await logActivity('Received',tx.coin_id,Number(tx.amount),`From ${String(tx.sender_device_id).slice(0,8)}…`)}}}if(changed)await persist();}catch(e){console.warn('shared sync',e)}}
async function fetchJSON(url,retries=2,timeoutMs=6500){
  let last;
  for(let attempt=0;attempt<=retries;attempt++){
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      const r=await fetch(url,{cache:'no-store',headers:{'accept':'application/json'},signal:controller.signal});
      clearTimeout(timer);
      if(r.ok)return r.json();
      last=new Error(`Market API ${r.status}`);
      if(![408,425,429,500,502,503,504].includes(r.status))throw last;
    }catch(e){
      clearTimeout(timer);
      last=e?.name==='AbortError'?new Error('Market request timed out'):e;
    }
    if(attempt<retries)await new Promise(resolve=>setTimeout(resolve,500*(attempt+1)));
  }
  throw last||new Error('Market request failed');
}
function currentProfileData(){return {deviceId,balances:{...balances},activity:[...activity],prefs:{...prefs},ledgerBootstrapped:true}}
async function saveActiveProfile(){
  if(activeProfile==='admin'){
    await chrome.storage.local.set({adminProfile:currentProfileData()});
    return;
  }
  if(!activeUsername)return;
  const d=await chrome.storage.local.get('userAccounts');
  const accounts={...(d.userAccounts||{}),...userAccounts};
  const existing=accounts[activeUsername]||{};
  accounts[activeUsername]={...existing,username:activeUsername,profile:currentProfileData()};
  userAccounts=accounts;
  await chrome.storage.local.set({userAccounts:accounts});
}
async function persist(render=true){
  await chrome.storage.local.set({marketCache:market,coinCache:coins});
  if(sessionUnlocked||profileSwitching)await saveActiveProfile();
  if(render&&sessionUnlocked)renderHome();
}
async function logActivity(type,id,amount,note=''){
  activity.unshift({id:Date.now(),type,coinId:id,amount:Number(amount)||0,note,time:Date.now()});
  activity=activity.slice(0,100);
  await saveActiveProfile();
}
async function switchProfile(kind,username=''){
  await initReady.catch(()=>{});
  profileSwitching=true;sessionUnlocked=false;sharedReady=false;
  seenTransferIds.clear();pendingBalancePushes.clear();
  try{
    let profile, accountRecord=null;
    if(kind==='admin'){
      const d=await chrome.storage.local.get('adminProfile');
      profile=d.adminProfile;
      if(!profile)throw new Error('Admin profile unavailable');
      activeProfile='admin';activeUsername='admin';
    }else{
      const key=String(username||'').trim().toLowerCase();
      const d=await chrome.storage.local.get(['userAccounts','adminProfile']);
      userAccounts={...(d.userAccounts||{})};
      accountRecord=userAccounts[key];
      if(!accountRecord?.profile)throw new Error('Account not found on this device');
      profile={...accountRecord.profile};
      activeProfile='user';activeUsername=key;
      const used=new Set();
      if(d.adminProfile?.deviceId)used.add(d.adminProfile.deviceId);
      for(const [u,a] of Object.entries(userAccounts))if(u!==key&&a?.profile?.deviceId)used.add(a.profile.deviceId);
      if(!profile.deviceId||used.has(profile.deviceId)){
        profile.deviceId=newDeviceId();
        profile.ledgerBootstrapped=false;
        userAccounts[key]={...accountRecord,profile};
        await chrome.storage.local.set({userAccounts});
      }
    }
    deviceId=profile.deviceId||newDeviceId();
    balances={...(profile.balances||{})};
    activity=Array.isArray(profile.activity)?[...profile.activity]:[];
    prefs={hideBalances:false,accountName:(kind==='admin'?'Admin':activeUsername),...(profile.prefs||{})};
    if(kind==='user')prefs.accountName=activeUsername;
    if(kind==='admin')prefs.accountName='Admin';
    document.querySelector('.account-name').textContent=prefs.accountName;
    renderHome();populateSecret();
    await ledger('register',{coins:Object.values(CORE).map(c=>({coinId:c.id,symbol:c.symbol}))});
    sharedReady=true;
    if(profile.ledgerBootstrapped===false){
      const payload={};
      for(const [coinId,amount] of Object.entries(balances))payload[coinId]={amount:Math.max(0,Number(amount)||0),symbol:coin(coinId).symbol};
      if(Object.keys(payload).length)await ledger('syncBalances',{balances:payload});
      profile.ledgerBootstrapped=true;
    }
    const st=await ledger('state');
    (st.transfers||[]).forEach(x=>seenTransferIds.add(x.id));
    for(const x of st.balances||[])balances[x.coin_id]=Number(x.amount)||0;
    sessionUnlocked=true;
    await saveActiveProfile();
    renderHome();populateSecret();
  }finally{profileSwitching=false;}
}

function holdingIds(){return Object.keys(balances).filter(id=>(Number(balances[id])||0)>0)}
function holdingValue(id){return (Number(balances[id])||0)*(Number(price(id))||0)}
function sortedHoldingIds(){return holdingIds().sort((a,b)=>{const diff=holdingValue(b)-holdingValue(a);if(Math.abs(diff)>1e-9)return diff;return (coins[a]?.rank||999999)-(coins[b]?.rank||999999)})}
function sortedMarketIds(limit=100){return Object.keys(coins).filter(id=>market[id]&&!holdingIds().includes(id)).sort((a,b)=>(coins[a]?.rank||999999)-(coins[b]?.rank||999999)).slice(0,limit)}
async function fetchMarkets(ids=[]){if(!ids.length)return;const chunks=[];for(let i=0;i<ids.length;i+=100)chunks.push(ids.slice(i,i+100));for(const group of chunks){try{const arr=await fetchJSON(`${API}/coins/markets?vs_currency=usd&ids=${encodeURIComponent(group.join(','))}&order=market_cap_desc&per_page=100&page=1&sparkline=true&price_change_percentage=24h`);arr.forEach(remember)}catch(e){console.warn('market refresh',e)}}await persist(false)}
async function loadMarketPage(page=1){if(marketLoading)return[];marketLoading=true;try{const arr=await fetchJSON(`${API}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=${page}&sparkline=true&price_change_percentage=24h`);arr.forEach(remember);marketHasMore=arr.length===100;marketPage=Math.max(marketPage,page);await persist(false);return arr}catch(e){console.warn(e);return[]}finally{marketLoading=false}}
async function refreshMarket(showToast=false){
  const visible=[...sortedHoldingIds(),...sortedMarketIds(90)];
  const ids=[...new Set([...visible,'solana','bitcoin','ethereum','usd-coin'])].slice(0,100);
  const before=Date.now();
  await fetchMarkets(ids);
  const fresh=ids.some(id=>(market[id]?.updated||0)>=before);
  const dot=$('statusDot');
  if(dot)dot.classList.toggle('live',fresh);
  if($('marketStatus'))$('marketStatus').textContent=fresh?`Live · updated ${new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`:'Market data temporarily unavailable';
  renderHome();
  if(showToast)toast(fresh?'Market data refreshed':'Could not refresh market data');
}
async function init(){
  const d=await chrome.storage.local.get(['balances','simBalances','marketCache','coinCache','activity','prefs','deviceId','adminProfile','userAccounts','accountUsername','accountPasswordHash','userProfile']);
  coins={...CORE,...(d.coinCache||{})};market={...(d.marketCache||{})};
  if(!d.adminProfile){
    const legacyBalances=d.balances?{...d.balances}:{solana:Number(d.simBalances?.SOL)||0,bitcoin:Number(d.simBalances?.BTC)||0,ethereum:Number(d.simBalances?.ETH)||0,'usd-coin':Number(d.simBalances?.USDC)||0};
    const adminProfile={deviceId:d.deviceId||newDeviceId(),balances:legacyBalances,activity:Array.isArray(d.activity)?d.activity:[],prefs:{hideBalances:false,accountName:'Account 1',...(d.prefs||{})},ledgerBootstrapped:true};
    await chrome.storage.local.set({adminProfile});
    d.adminProfile=adminProfile;
  }
  userAccounts={...(d.userAccounts||{})};
  if(d.accountUsername&&d.accountPasswordHash&&d.userProfile){
    const legacyUser=String(d.accountUsername).trim().toLowerCase();
    if(legacyUser&&!userAccounts[legacyUser]){
      const lp={...d.userProfile};
      if(!lp.deviceId||lp.deviceId===d.adminProfile?.deviceId){lp.deviceId=newDeviceId();lp.ledgerBootstrapped=false;}
      lp.prefs={hideBalances:false,...(lp.prefs||{}),accountName:legacyUser};userAccounts[legacyUser]={username:legacyUser,passwordHash:d.accountPasswordHash,profile:lp};
      await chrome.storage.local.set({userAccounts});
    }
  }
  activeProfile='';activeUsername='';deviceId='';balances={};activity=[];prefs={hideBalances:false,accountName:'Account 1'};
  sharedReady=false;sessionUnlocked=false;profileSwitching=false;
  document.querySelector('.account-name').textContent='Account 1';renderHome();populateSecret();
  await loadMarketPage(1);await refreshMarket(false);renderHome();
  setInterval(()=>refreshMarket(false),60000);setInterval(()=>syncSharedState(true),5000);
  setInterval(()=>{
    const el=$('marketStatus');if(!el)return;
    const stamps=Object.values(market).map(x=>Number(x.updated)||0).filter(Boolean);if(!stamps.length)return;
    const age=Math.max(0,Math.floor((Date.now()-Math.max(...stamps))/1000));
    el.textContent=age<60?`Live · updated ${age}s ago`:`Live · updated ${Math.floor(age/60)}m ago`;
  },1000);
}
function renderHome(){ensureOwnerBar();ensureOwnerViewBar();
  const list=$('tokenList');
  list.innerHTML='';
  const held=sortedHoldingIds();
  const browse=sortedMarketIds(100);
  let total=0,prevTotal=0;
  held.forEach(id=>{
    const c=coin(id),a=Number(balances[id])||0,p=price(id),ch=change(id),usd=a*p;
    total+=usd;prevTotal+=ch>-99?usd/(1+ch/100):usd;
    const row=document.createElement('button');row.className='token-row';row.dataset.coin=id;
    row.innerHTML=`<img class="coin-logo" src="${imageFor(c)}" alt=""><div class="coin-main"><strong>${esc(c.name)}</strong><span>${fmtAmt(a)} ${esc(c.symbol)}</span></div><div class="coin-value"><strong>${fmtUSD(usd)}</strong><span class="${ch>=0?'positive':'negative'}">${ch>=0?'+':''}${ch.toFixed(2)}%</span></div>`;
    list.appendChild(row)
  });
  if(browse.length){
    const divider=document.createElement('div');divider.className='asset-section-label';divider.textContent=held.length?'Market':'Assets';list.appendChild(divider);
    browse.forEach(id=>{
      const c=coin(id),p=price(id),ch=change(id),row=document.createElement('button');row.className='token-row market-token-row';row.dataset.coin=id;
      row.innerHTML=`<img class="coin-logo" src="${imageFor(c)}" alt=""><div class="coin-main"><strong>${esc(c.name)}</strong><span>${esc(c.symbol)}${c.rank&&c.rank<999999?` · #${c.rank}`:''}</span></div><div class="coin-value"><strong>${p?fmtUSD(p):'—'}</strong><span class="${ch>=0?'positive':'negative'}">${ch>=0?'+':''}${ch.toFixed(2)}%</span></div>`;
      list.appendChild(row)
    })
  }
  if(!held.length&&!browse.length)list.innerHTML='<div class="empty-state"><strong>Loading assets…</strong><span>Market data will appear here.</span></div>';
  const delta=total-prevTotal,pct=prevTotal?delta/prevTotal*100:0;
  $('portfolioBalance').textContent=fmtUSD(total);$('portfolioDelta').textContent=`${delta>=0?'+':''}${fmtUSD(delta)}`;$('portfolioPct').textContent=`${pct>=0?'+':''}${pct.toFixed(2)}%`;$('portfolioDelta').style.color=delta<0?'var(--red)':'#d6d6d8';
  if(prefs.hideBalances){$('portfolioBalance').textContent='••••••';$('portfolioDelta').textContent='••••';$('portfolioPct').textContent='••••';document.querySelectorAll('.token-row:not(.market-token-row) .coin-value strong').forEach(x=>x.textContent='••••')}
}
function openSheet(title,html){$('sheetTitle').textContent=title;$('sheetBody').innerHTML=html;$('sheetOverlay').hidden=false}
function closeSheet(){$('sheetOverlay').hidden=true;$('sheetBody').innerHTML=''}
$('sheetClose').onclick=closeSheet;$('sheetBack').onclick=closeSheet;$('sheetOverlay').onclick=e=>{if(e.target===$('sheetOverlay'))closeSheet()};
function chip(id,coinId){const c=coin(coinId);return `<button id="${id}" class="asset-chip"><img src="${imageFor(c)}" alt=""><span>${esc(c.symbol)}</span><svg viewBox="0 0 16 16"><path d="m4 6 4 4 4-4"/></svg></button>`}
function optionMarkup(id,attr='pick'){const c=coin(id);return `<button class="asset-option" data-${attr}="${esc(id)}"><img src="${imageFor(c)}" alt=""><span><strong>${esc(c.name)}</strong><small>${esc(c.symbol)} · ${fmtUSD(price(id))}</small></span><span>${fmtAmt(balances[id]||0)}</span></button>`}
function picker(onPick){const ids=[...new Set([...sortedHoldingIds(),...Object.keys(coins).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999)).slice(0,100)])];openSheet('Select asset',`<input id="pickerSearch" class="search-input" placeholder="Search all assets"><div id="pickerList" class="asset-picker">${ids.map(id=>optionMarkup(id)).join('')}</div>`);const bind=()=>document.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>onPick(b.dataset.pick));bind();$('pickerSearch').oninput=async()=>{const q=$('pickerSearch').value.trim();if(q.length<2){$('pickerList').innerHTML=ids.map(id=>optionMarkup(id)).join('');bind();return}const results=await searchCoins(q);$('pickerList').innerHTML=results.map(id=>optionMarkup(id)).join('')||'<div class="empty-state"><strong>No assets found</strong></div>';bind()}}
async function searchCoins(q){try{const s=await fetchJSON(`${API}/search?query=${encodeURIComponent(q)}`);const rows=(s.coins||[]).slice(0,30);rows.forEach(x=>{coins[x.id]={...(coins[x.id]||{}),id:x.id,symbol:String(x.symbol||'').toUpperCase(),name:x.name,logo:x.large||x.thumb||'',rank:x.market_cap_rank||999999}});await fetchMarkets(rows.map(x=>x.id));return rows.map(x=>x.id)}catch(e){console.warn(e);return Object.keys(coins).filter(id=>coin(id).name.toLowerCase().includes(q.toLowerCase())||coin(id).symbol.toLowerCase().includes(q.toLowerCase())).slice(0,30)}}
function defaultOther(id){return id==='usd-coin'?'solana':'usd-coin'}
function openSwap(from='solana',to='usd-coin'){
  if(from===to)to=defaultOther(from);
  const fcoin=coin(from),tcoin=coin(to);
  let f=from,t=to,unit='coin',maxLocked=false;
  openSheet('Swap Tokens',`<div class="swap-screen"><div class="swap-block"><div class="swap-caption-row"><div class="swap-caption">You Pay</div><div class="send-unit-toggle swap-unit-toggle"><button id="swapUnitCoin" class="active">${esc(fcoin.symbol)}</button><button id="swapUnitUsd">USD</button></div></div><div class="swap-amount-row"><input id="swapInput" type="number" min="0" step="any" placeholder="0">${chip('fromChip',from)}</div><div class="swap-sub"><span id="fromUsd">$0.00</span><span class="swap-balance-wrap"><span id="fromBalance"></span><button id="swapMax" type="button">MAX</button></span></div></div><button id="switchSwap" class="swap-switch"><svg viewBox="0 0 24 24"><path d="M8 4v14M5 15l3 3 3-3M16 20V6M13 9l3-3 3 3"/></svg></button><div class="swap-block"><div class="swap-caption">You Receive</div><div class="swap-amount-row"><input id="swapOutput" value="0" readonly>${chip('toChip',to)}</div><div class="swap-sub"><span id="toUsd">$0.00</span><span id="toBalance"></span></div></div><div class="rate-card"><div class="rate-row"><span>Market rate</span><strong id="swapRate">—</strong></div><div class="rate-row"><span>Price source</span><strong>CoinGecko</strong></div></div><button id="doSwap" class="primary" disabled>Swap</button></div>`);
  const input=$('swapInput'),out=$('swapOutput'),btn=$('doSwap'),coinBtn=$('swapUnitCoin'),usdBtn=$('swapUnitUsd');
  const coinAmount=()=>{if(maxLocked)return Number(balances[f])||0;const v=Number(input.value)||0,pf=price(f);return unit==='usd'?(pf>0?v/pf:0):v};
  function refresh(){const a=coinAmount(),available=Number(balances[f])||0,pf=price(f),pt=price(t),usd=a*pf,recv=pt>0?usd/pt:0;if(maxLocked){input.value=unit==='usd'?(pf>0?(available*pf).toFixed(2):''):String(Number(available.toFixed(8)));}out.value=a?fmtAmt(recv):'0';$('fromUsd').textContent=unit==='usd'?(a>0?`≈ ${fmtAmt(a)} ${coin(f).symbol}`:'0 '+coin(f).symbol):fmtUSD(usd);$('toUsd').textContent=fmtUSD(recv*pt);$('fromBalance').textContent=`${fmtAmt(available)} ${coin(f).symbol}`;$('toBalance').textContent=`${fmtAmt(balances[t]||0)} ${coin(t).symbol}`;$('swapRate').textContent=pf&&pt?`1 ${coin(f).symbol} = ${fmtAmt(pf/pt,8)} ${coin(t).symbol}`:'Price unavailable';btn.disabled=!(a>0&&a<=available+1e-12&&f!==t&&pf>0&&pt>0);btn.textContent=a>available+1e-12?'Insufficient balance':'Swap'}
  function setUnit(next){if(unit===next)return;const currentCoin=coinAmount(),pf=price(f);unit=next;coinBtn.classList.toggle('active',unit==='coin');usdBtn.classList.toggle('active',unit==='usd');input.value=currentCoin>0?(unit==='usd'&&pf>0?(currentCoin*pf).toFixed(2):String(Number(currentCoin.toFixed(8)))):'';input.placeholder=unit==='usd'?'0.00':'0';refresh()}
  coinBtn.onclick=()=>setUnit('coin');usdBtn.onclick=()=>setUnit('usd');input.oninput=()=>{maxLocked=false;refresh()};
  $('swapMax').onclick=()=>{maxLocked=true;refresh()};
  $('fromChip').onclick=()=>picker(s=>openSwap(s,s===t?defaultOther(s):t));$('toChip').onclick=()=>picker(s=>openSwap(f,s===f?defaultOther(s):s));$('switchSwap').onclick=()=>openSwap(t,f);
  btn.onclick=async()=>{const a=coinAmount(),pf=price(f),pt=price(t),recv=a*pf/pt;if(!(a>0)||a>(balances[f]||0)+1e-12||!Number.isFinite(recv))return;balances[f]-=a;balances[t]=(balances[t]||0)+recv;await logActivity('Swap',f,-a,`Received ${fmtAmt(recv)} ${coin(t).symbol}`);await persist();try{await pushSharedBalances([f,t])}catch(e){console.warn('shared balance push',e)}toast(`Swapped ${fmtAmt(a)} ${coin(f).symbol} → ${fmtAmt(recv)} ${coin(t).symbol}`);openSwap(f,t)};
  refresh();const swapLiveTimer=setInterval(()=>{if(!$('swapInput'))return clearInterval(swapLiveTimer);refresh()},1000)
}
const chartMemoryCache=new Map();
const chartInflight=new Map();
const CHART_TTL={"1D":2*60*1000,"1W":5*60*1000,"1M":10*60*1000,"1Y":30*60*1000};
function chartCacheKey(id,range){return `${id}:${range}`}
async function getCachedChart(id,range){
  const key=chartCacheKey(id,range),mem=chartMemoryCache.get(key);
  if(mem?.values?.length>1)return mem;
  try{const o=await chrome.storage.local.get(`chart:${key}`),v=o[`chart:${key}`];if(v?.values?.length>1){chartMemoryCache.set(key,v);return v}}catch{}
  return null;
}
async function saveCachedChart(id,range,values){
  const key=chartCacheKey(id,range),entry={values,timestamp:Date.now()};chartMemoryCache.set(key,entry);
  try{await chrome.storage.local.set({[`chart:${key}`]:entry})}catch{}
  return entry;
}
async function requestChart(id,range){
  const key=chartCacheKey(id,range);if(chartInflight.has(key))return chartInflight.get(key);
  const task=(async()=>{
    const days={"1D":1,"1W":7,"1M":30,"1Y":365}[range]||1;
    const url=`${API}/coins/${encodeURIComponent(id)}/market_chart?vs_currency=usd&days=${days}&precision=full`;
    // Keep chart requests bounded. A stalled public API response must never leave
    // the asset page permanently stuck in its loading state.
    const d=await fetchJSON(url,2,5000);
    const values=(d.prices||[]).map(x=>Number(x[1])).filter(Number.isFinite);
    if(values.length<2)throw new Error('No chart data');
    return saveCachedChart(id,range,values);
  })().finally(()=>chartInflight.delete(key));
  chartInflight.set(key,task);return task;
}
async function loadChart(id,range='1D'){
  const wrap=$('chartWrap');if(!wrap)return;
  const cached=await getCachedChart(id,range),ttl=CHART_TTL[range]||300000;
  const spark=(market[id]?.sparkline||[]).filter(Number.isFinite);
  let displayed=false;

  if(cached?.values?.length>1){
    drawChart(wrap,cached.values);showChartAge(wrap,cached.timestamp);displayed=true;
    if(Date.now()-cached.timestamp<ttl)return;
  }else if(spark.length>2&&(range==='1D'||range==='1W')){
    // CoinGecko's market listing already contains a 7-day sparkline. Render that
    // instantly so short-range charts never wait on a second network request.
    const count=range==='1D'?Math.max(2,Math.floor(spark.length/7)):spark.length;
    drawChart(wrap,spark.slice(-count));showChartAge(wrap,market[id]?.updated||Date.now(),true);displayed=true;
  }else{
    wrap.innerHTML='<div class="chart-loading">Loading market chart…</div>';
  }

  // Independent UI guard: even if a browser/network bug prevents fetch from
  // settling, replace the spinner instead of leaving it on screen forever.
  const guard=setTimeout(()=>{
    if(!$('chartWrap')||$('chartWrap')!==wrap)return;
    if(wrap.querySelector('.chart-loading')&&!wrap.querySelector('svg')){
      wrap.innerHTML='<div class="chart-loading"><span>Chart unavailable</span><button id="retryChart" class="chart-retry" type="button">Retry</button></div>';
      const retry=$('retryChart');if(retry)retry.onclick=()=>loadChart(id,range);
    }
  },9000);

  try{
    const fresh=await requestChart(id,range);
    clearTimeout(guard);
    if(!$('chartWrap')||$('chartWrap')!==wrap)return;
    drawChart(wrap,fresh.values);showChartAge(wrap,fresh.timestamp);
  }catch(e){
    clearTimeout(guard);
    console.warn('chart request',id,range,e);
    if(!$('chartWrap')||$('chartWrap')!==wrap)return;
    if(cached?.values?.length>1){drawChart(wrap,cached.values);showChartAge(wrap,cached.timestamp,true);return}
    if(spark.length>2&&(range==='1D'||range==='1W')){
      const count=range==='1D'?Math.max(2,Math.floor(spark.length/7)):spark.length;
      drawChart(wrap,spark.slice(-count));showChartAge(wrap,market[id]?.updated||Date.now(),true);return;
    }
    if(!displayed){
      wrap.innerHTML='<div class="chart-loading"><span>Chart unavailable</span><button id="retryChart" class="chart-retry" type="button">Retry</button></div>';
      const retry=$('retryChart');if(retry)retry.onclick=()=>loadChart(id,range);
    }
  }
}

function showChartAge(wrap,timestamp,stale=false){
  const note=document.createElement('div');note.className='chart-fallback-note';
  const age=Math.max(0,Date.now()-Number(timestamp||Date.now())),mins=Math.floor(age/60000);
  note.textContent=stale?(mins?`Last chart · ${mins}m ago`:'Last chart'):(mins?`Updated ${mins}m ago`:'Updated now');wrap.appendChild(note);
}
function drawChart(wrap,vals){
  const {line,area}=pointsToPath(vals);
  wrap.innerHTML=`<svg viewBox="0 0 320 170" preserveAspectRatio="none"><defs><linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8d7cf8" stop-opacity=".28"/><stop offset="1" stop-color="#8d7cf8" stop-opacity="0"/></linearGradient></defs><path class="chart-area" d="${area}"/><path class="chart-line" d="${line}"/></svg>`;
}
async function ensureCoinMarket(id){if(price(id)>0)return;await fetchMarkets([id])}
async function openToken(id,range='1D'){await ensureCoinMarket(id);const c=coin(id),p=price(id),ch=change(id);openSheet(c.name,`<div class="asset-hero"><div class="asset-title-row"><img src="${imageFor(c)}" alt=""><div><h3>${esc(c.name)}</h3><span>${esc(c.symbol)} · CoinGecko market</span></div></div><div class="asset-price">${p?fmtUSD(p):'—'}</div><div class="asset-change ${ch>=0?'positive':'negative'}">${ch>=0?'+':''}${ch.toFixed(2)}% today</div><div id="chartWrap" class="chart-wrap"></div><div class="range-tabs" style="grid-template-columns:repeat(4,1fr)"><button data-range="1D" class="${range==='1D'?'active':''}">1D</button><button data-range="1W" class="${range==='1W'?'active':''}">1W</button><button data-range="1M" class="${range==='1M'?'active':''}">1M</button><button data-range="1Y" class="${range==='1Y'?'active':''}">1Y</button></div><div class="asset-stats"><div class="stat"><span>Your balance</span><strong>${fmtAmt(balances[id]||0)} ${esc(c.symbol)}</strong></div><div class="stat"><span>Value</span><strong>${fmtUSD((balances[id]||0)*p)}</strong></div><div class="stat"><span>24h high</span><strong>${market[id]?.high?fmtUSD(market[id].high):'—'}</strong></div><div class="stat"><span>24h low</span><strong>${market[id]?.low?fmtUSD(market[id].low):'—'}</strong></div></div><div class="asset-actions"><button id="assetReceive" class="asset-action"><svg viewBox="0 0 24 24"><path d="M12 3v13M7 11l5 5 5-5M5 21h14"/></svg><span>Receive</span></button><button id="assetSend" class="asset-action"><svg viewBox="0 0 24 24"><path d="M12 21V8M7 13l5-5 5 5M5 3h14"/></svg><span>Send</span></button><button id="assetSwap" class="asset-action accent"><svg viewBox="0 0 24 24"><path d="M7 7h12l-3-3M17 17H5l3 3"/></svg><span>Swap</span></button></div></div>`);document.querySelectorAll('[data-range]').forEach(b=>b.onclick=()=>openToken(id,b.dataset.range));$('assetReceive').onclick=()=>openReceive(id);$('assetSend').onclick=()=>openSend(id);$('assetSwap').onclick=()=>openSwap(id,defaultOther(id));loadChart(id,range)}
async function openReceive(id=sortedHoldingIds()[0]||'solana'){const c=coin(id);openSheet('Receive',`<div class="asset-hero"><div class="asset-title-row"><img src="${imageFor(c)}" alt=""><div><h3>${esc(c.name)}</h3><span>Receive ${esc(c.symbol)}</span></div></div><div class="field"><label>Asset</label><button id="receiveAssetPick" class="secondary">${esc(c.name)} (${esc(c.symbol)})</button></div><div class="field"><label>Receive address</label><input id="receiveAddress" class="address-input" value="Loading address…" readonly></div><button id="copyReceiveAddress" class="primary" disabled>Copy address</button></div>`);$('receiveAssetPick').onclick=()=>picker(openReceive);try{const address=await sharedAddress(id);$('receiveAddress').value=address;$('copyReceiveAddress').disabled=false;$('copyReceiveAddress').onclick=async()=>{try{await navigator.clipboard.writeText(address);$('copyReceiveAddress').textContent='Copied'}catch{}}}catch(e){$('receiveAddress').value='Could not load address';toast(e.message)}}
function openSend(id=sortedHoldingIds()[0]||'solana'){
  const c=coin(id);
  let unit='coin',maxLocked=false;
  openSheet('Send',`<div class="field"><label>Asset</label><button id="sendAssetPick" class="secondary">${esc(c.name)} (${esc(c.symbol)})</button></div><div class="field"><label>Recipient</label><input id="sendRecipient" placeholder="Recipient address"></div><div class="send-amount-head"><label>Amount</label><div class="send-unit-toggle"><button id="sendUnitCoin" class="active">${esc(c.symbol)}</button><button id="sendUnitUsd">USD</button></div></div><div class="send-amount-box"><input id="sendAmount" type="number" min="0" step="any" placeholder="0"><button id="sendMax" type="button">MAX</button></div><div class="send-amount-meta"><span id="sendAvailable">Available ${fmtAmt(Number(balances[id])||0)} ${esc(c.symbol)}</span><strong id="sendConversion">${price(id)>0?fmtUSD(0):'Price unavailable'}</strong></div><button id="sendConfirm" class="primary">Send</button></div>`);
  $('sendAssetPick').onclick=()=>picker(openSend);
  const input=$('sendAmount'),coinBtn=$('sendUnitCoin'),usdBtn=$('sendUnitUsd'),conversion=$('sendConversion');
  const coinAmount=()=>{if(maxLocked)return Number(balances[id])||0;const v=Number(input.value)||0,pNow=price(id);return unit==='usd'?(pNow>0?v/pNow:0):v};
  const redraw=()=>{const a=coinAmount(),balNow=Number(balances[id])||0,pNow=price(id);if(maxLocked)input.value=unit==='usd'?(pNow>0?(balNow*pNow).toFixed(2):''):String(Number(balNow.toFixed(8)));$('sendAvailable').textContent=`Available ${fmtAmt(balNow)} ${c.symbol}`;conversion.textContent=unit==='usd'?(pNow>0?`≈ ${fmtAmt(a)} ${c.symbol}`:'Price unavailable'):(pNow>0?`≈ ${fmtUSD(a*pNow)}`:'Price unavailable');};
  const setUnit=next=>{if(unit===next)return;const currentCoin=coinAmount(),pNow=price(id);unit=next;coinBtn.classList.toggle('active',unit==='coin');usdBtn.classList.toggle('active',unit==='usd');input.value=currentCoin>0?(unit==='usd'&&pNow>0?(currentCoin*pNow).toFixed(2):String(Number(currentCoin.toFixed(8)))):'';input.placeholder=unit==='usd'?'0.00':'0';redraw();};
  coinBtn.onclick=()=>setUnit('coin');usdBtn.onclick=()=>setUnit('usd');input.oninput=()=>{maxLocked=false;redraw()};
  $('sendMax').onclick=()=>{maxLocked=true;redraw()};
  $('sendConfirm').onclick=async()=>{const a=coinAmount(),balNow=Number(balances[id])||0,pNow=price(id),recipient=$('sendRecipient').value.trim();if(!(a>0)||a>balNow+1e-12)return toast('Check amount and balance');if(unit==='usd'&&!(pNow>0))return toast('Live price unavailable');if(!recipient)return toast('Enter a recipient address');const btn=$('sendConfirm');btn.disabled=true;btn.textContent='Sending…';try{await pushSharedBalances([id]);const d=await ledger('transfer',{coinId:id,symbol:c.symbol,amount:a,recipientAddress:recipient});balances[id]=Number(d.balance)||0;await logActivity('Sent',id,-a,`To ${recipient.slice(0,10)}…`);await persist();showSendToast(c,a,`To ${recipient.slice(0,6)}…${recipient.slice(-4)}`);setTimeout(closeSheet,700)}catch(e){toast(e.message);btn.disabled=false;btn.textContent='Send'}};redraw();const sendLiveTimer=setInterval(()=>{if(!$('sendAmount'))return clearInterval(sendLiveTimer);redraw()},1000);
}
function openBuy(id='solana'){if(ownerSession&&ownerViewUser)return toast('Use Owner Console to manage this account');if(!hasBuyAccess())return toast('Premium or admin access required');const c=coin(id);openSheet('Buy',`<div class="field"><label>Asset</label><button id="buyAssetPick" class="secondary">${esc(c.name)} (${esc(c.symbol)})</button></div><div class="field"><label>USD amount</label><input id="buyAmount" type="number" min="0" placeholder="100"></div><button id="buyConfirm" class="primary">Add balance</button>`);$('buyAssetPick').onclick=()=>picker(openBuy);$('buyConfirm').onclick=async()=>{const usd=Number($('buyAmount').value);if(!(usd>0)||price(id)<=0)return toast('Enter a valid amount');const added=usd/price(id);balances[id]=(balances[id]||0)+added;await logActivity('Buy',id,added,`${fmtUSD(usd)} display purchase`);await persist();try{await pushSharedBalances([id])}catch(e){console.warn('shared balance push',e)}populateSecret();toast(`Added ${fmtUSD(usd)} of ${c.symbol}`);closeSheet()}}
function marketRows(ids,attr='market'){return ids.map(id=>{const c=coin(id),ch=change(id);return `<button class="asset-option" data-${attr}="${esc(id)}"><img src="${imageFor(c)}" alt=""><span><strong>${esc(c.name)}</strong><small>${esc(c.symbol)}${c.rank&&c.rank<999999?` · #${c.rank}`:''}</small></span><span><strong>${price(id)?fmtUSD(price(id)):'—'}</strong><small class="${ch>=0?'positive':'negative'}">${ch>=0?'+':''}${ch.toFixed(2)}%</small></span></button>`}).join('')}
async function openExplore(){openSheet('Explore',`<input id="exploreSearch" class="search-input" placeholder="Search all coins"><div class="section-label">Markets</div><div id="exploreList" class="asset-picker"></div><button id="loadMoreMarkets" class="secondary">Load more</button>`);let ids=[...sortedHoldingIds(),...Object.keys(coins).filter(id=>market[id]&&!holdingIds().includes(id)).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999))];if(ids.length<50){await loadMarketPage(1);ids=[...sortedHoldingIds(),...Object.keys(coins).filter(id=>market[id]&&!holdingIds().includes(id)).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999))]}const draw=()=>{$('exploreList').innerHTML=marketRows(ids,'market');document.querySelectorAll('[data-market]').forEach(b=>b.onclick=()=>openToken(b.dataset.market))};draw();$('exploreSearch').oninput=async()=>{const q=$('exploreSearch').value.trim();if(!q){ids=Object.keys(coins).filter(id=>market[id]).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999));draw();return}if(q.length<2)return;ids=await searchCoins(q);draw()};$('loadMoreMarkets').onclick=async()=>{const next=marketPage+1;const arr=await loadMarketPage(next);if(!arr.length){$('loadMoreMarkets').textContent='No more loaded';return}ids=[...sortedHoldingIds(),...Object.keys(coins).filter(id=>market[id]&&!holdingIds().includes(id)).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999))];draw()}}
function openActivity(){openSheet('Activity',`<div class="activity-list">${activity.length?activity.map(a=>{const id=a.coinId||({SOL:'solana',BTC:'bitcoin',ETH:'ethereum',USDC:'usd-coin'}[a.symbol]||a.symbol),c=coin(id),positive=a.amount>0;return `<div class="activity-row"><img src="${imageFor(c)}" alt=""><div><strong>${esc(a.type)} · ${esc(c.name)}</strong><span>${new Date(a.time).toLocaleString([],{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</span><small>${esc(a.note||'')}</small></div><div class="amount ${positive?'positive':''}">${positive?'+':''}${fmtAmt(a.amount)} ${esc(c.symbol)}</div></div>`}).join(''):'<div class="empty-state"><strong>No activity yet</strong></div>'}</div>`)}
function openSettings(){
  const resetAccess=hasResetAccess()?`<button id="resetWalletSetting" class="menu-row"><span class="left"><strong class="danger">Reset balances</strong><small>Set all account balances to zero</small></span><span class="value danger">Reset</span></button>`:'';
  const adminPassword=(adminSession&&!ownerSession)?`<button id="changeAdminPasswordSetting" class="menu-row"><span class="left"><strong>Change admin password</strong><small>Owner key required</small></span><span class="value">Change</span></button>`:'';
  const accountPassword=!adminSession?`<button id="changeAccountPasswordSetting" class="menu-row"><span class="left"><strong>Change password</strong><small>Update this account password</small></span><span class="value">Change</span></button>`:'';
  const passkeyRow=!adminSession?`<button id="premiumPasskeySetting" class="menu-row"><span class="left"><strong>PASSKEY</strong><small>${premiumAccess?'Premium access active':'Redeem a premium key'}</small></span><span class="value">${premiumAccess?'Active':'Enter'}</span></button>`:'';
  openSheet('Settings',`<div class="menu-list"><button id="hideBalanceSetting" class="menu-row"><span class="left"><strong>Hide balances</strong><small>Mask portfolio values on the home screen</small></span><span class="toggle ${prefs.hideBalances?'on':''}"></span></button><button id="refreshSetting" class="menu-row"><span class="left"><strong>Refresh market data</strong><small>Update held-asset prices now</small></span><span class="value">Refresh</span></button><button id="clearActivitySetting" class="menu-row"><span class="left"><strong>Clear activity</strong><small>Remove local history</small></span><span class="value">Clear</span></button>${accountPassword}${passkeyRow}${adminPassword}${resetAccess}<div class="account-card"><strong>Market data</strong><span>CoinGecko live prices, coin artwork, and historical charts. Data is cached to reduce API requests.</span></div></div>`);
  $('hideBalanceSetting').onclick=async()=>{prefs.hideBalances=!prefs.hideBalances;await persist();openSettings()};
  $('refreshSetting').onclick=()=>refreshMarket(true);
  $('clearActivitySetting').onclick=async()=>{activity=[];await persist();openSettings();toast('Activity cleared')};
  const changeAccount=$('changeAccountPasswordSetting');
  if(changeAccount)changeAccount.onclick=()=>openAccountPasswordChange();
  const changeAdmin=$('changeAdminPasswordSetting');
  if(changeAdmin)changeAdmin.onclick=()=>openAdminPasswordChange();
  const passkeyBtn=$('premiumPasskeySetting');
  if(passkeyBtn)passkeyBtn.onclick=()=>openPremiumPasskey();
  const reset=$('resetWalletSetting');
  if(reset)reset.onclick=async()=>{if(!hasResetAccess())return toast('Premium or admin access required');const ids=Object.keys(balances);balances={};activity=[];await persist();if(sharedReady){for(const id of ids)balances[id]=0;try{await pushSharedBalances(ids)}catch(e){console.warn('shared balance push',e)}balances={};await persist(false)}populateSecret();toast('Balances reset');openSettings()};
}
function openPremiumPasskey(){
  if(adminSession)return;
  if(premiumAccess){
    openSheet('PASSKEY',`<div class="account-card"><strong>Premium active</strong><span>This account has access to Buy and Reset balances.</span></div><button id="premiumDone" class="primary">Done</button>`);
    $('premiumDone').onclick=closeSheet;
    return;
  }
  openSheet('PASSKEY',`<div class="field"><label>Premium key</label><input id="premiumKeyInput" type="password" autocomplete="off" placeholder="Enter premium key"></div><div id="premiumKeyError" class="form-inline-error"></div><button id="redeemPremiumKey" class="primary">Redeem key</button>`);
  $('redeemPremiumKey').onclick=async()=>{
    const key=String($('premiumKeyInput').value||'').trim(),error=$('premiumKeyError'),btn=$('redeemPremiumKey');
    if(!key){error.textContent='Enter a premium key';return}
    btn.disabled=true;btn.textContent='Checking…';error.textContent='';
    try{
      const d=await premiumApi('redeem',{key});
      premiumAccess=!!d.premium;
      applyAccountAccess();
      toast('Premium access unlocked');
      openSettings();
    }catch(e){
      error.textContent=e?.message||'Could not redeem key';
      btn.disabled=false;btn.textContent='Redeem key';
    }
  };
}
function openAccountPasswordChange(){
  if(adminSession)return;
  openSheet('Change password',`<div class="field"><label>Current password</label><input id="currentAccountPassword" type="password" autocomplete="current-password" placeholder="Current password"></div><div class="field"><label>New password</label><input id="newAccountPasswordSetting" type="password" autocomplete="new-password" placeholder="New password"></div><div class="field"><label>Confirm password</label><input id="confirmAccountPasswordSetting" type="password" autocomplete="new-password" placeholder="Confirm password"></div><div id="accountPasswordError" class="form-inline-error"></div><button id="saveAccountPassword" class="primary">Change password</button>`);
  $('saveAccountPassword').onclick=async()=>{
    const current=$('currentAccountPassword').value,newPassword=$('newAccountPasswordSetting').value,confirm=$('confirmAccountPasswordSetting').value,error=$('accountPasswordError');
    error.textContent='';
    const stored=await chrome.storage.local.get(['userAccounts','adminPasswordHash']);
    const accounts={...(stored.userAccounts||{})};
    const currentAccount=accounts[activeUsername];
    if(!currentAccount?.passwordHash||await passwordDigest(current)!==currentAccount.passwordHash){error.textContent='Current password is incorrect';$('currentAccountPassword').select();return;}
    if(newPassword.length<4){error.textContent='Use at least 4 characters';return;}
    if(newPassword!==confirm){error.textContent='Passwords do not match';return;}
    const nextHash=await passwordDigest(newPassword);
    if(nextHash===(stored.adminPasswordHash||DEFAULT_ADMIN_PASSWORD_HASH)){error.textContent='Choose a different password';return;}
    accounts[activeUsername]={...currentAccount,passwordHash:nextHash};
    userAccounts=accounts;
    await chrome.storage.local.set({userAccounts:accounts});
    await authApi('set',{username:activeUsername,deviceId,passwordHash:nextHash});
    toast('Password changed');
    openSettings();
  };
}

function openAdminPasswordChange(){
  if(!adminSession&&!ownerSession)return;
  openSheet('Change admin password',`<div class="field"><label>Owner key</label><input id="ownerKeyInput" type="password" autocomplete="off" placeholder="Owner key"></div><div class="field"><label>New admin password</label><input id="newAdminPassword" type="password" autocomplete="new-password" placeholder="New password"></div><div class="field"><label>Confirm password</label><input id="confirmAdminPassword" type="password" autocomplete="new-password" placeholder="Confirm password"></div><div id="adminPasswordError" class="form-inline-error"></div><button id="saveAdminPassword" class="primary">Change password</button>`);
  $('saveAdminPassword').onclick=async()=>{
    const owner=$('ownerKeyInput').value,newPassword=$('newAdminPassword').value,confirm=$('confirmAdminPassword').value,error=$('adminPasswordError');
    error.textContent='';
    if(await passwordDigest(owner)!==OWNER_KEY_HASH){error.textContent='Invalid owner key';$('ownerKeyInput').select();return;}
    if(newPassword.length<4){error.textContent='Use at least 4 characters';return;}
    if(newPassword!==confirm){error.textContent='Passwords do not match';return;}
    const normal=await chrome.storage.local.get('userAccounts');
    const nextHash=await passwordDigest(newPassword);
    const clashes=Object.values(normal.userAccounts||{}).some(a=>a&&a.passwordHash===nextHash);
    if(clashes){error.textContent='Admin and account passwords must be different';return;}
    await chrome.storage.local.set({adminPasswordHash:nextHash});
    toast('Admin password changed');
    openSettings();
  };
}

async function logoutWallet(){
  if(sessionUnlocked)await saveActiveProfile();
  adminSession=false;premiumAccess=false;ownerSession=false;ownerToken='';ownerViewUser='';ownerViewSnapshot=null;clearInterval(ownerHeartbeatTimer);sessionUnlocked=false;sharedReady=false;profileSwitching=false;
  activeProfile='';activeUsername='';deviceId='';balances={};activity=[];prefs={hideBalances:false,accountName:'Account 1'};
  seenTransferIds.clear();pendingBalancePushes.clear();
  applyAccountAccess();closeSheet();
  document.querySelector('.account-name').textContent='Account 1';renderHome();
  const screen=$('lockScreen'),input=$('unlockPassword'),username=$('unlockUsername'),error=$('unlockError');
  if(screen)screen.hidden=false;if(input)input.value='';if(username){username.value='';setTimeout(()=>username.focus(),30)}if(error)error.textContent='';
}
async function createFreshWalletAccount(password,username,preparedDeviceId){
  await initReady.catch(()=>{});
  if(sessionUnlocked&&(activeProfile==='admin'||activeProfile==='user'))await saveActiveProfile();
  const key=String(username).trim().toLowerCase();
  const freshId=preparedDeviceId||newDeviceId();
  const profile={deviceId:freshId,balances:{},activity:[],prefs:{hideBalances:false,accountName:key},ledgerBootstrapped:false};
  // Claim the globally unique username before saving the account locally.
  const previousId=deviceId;
  deviceId=freshId;
  try{
    await ledger('claimUsername',{username:key});
    await ledger('register',{coins:Object.values(CORE).map(c=>({coinId:c.id,symbol:c.symbol}))});
  }catch(e){deviceId=previousId;throw e}
  const d=await chrome.storage.local.get('userAccounts');
  const accounts={...(d.userAccounts||{}),...userAccounts};
  if(accounts[key]){deviceId=previousId;throw new Error('Username already exists on this device')}
  const accountHash=await passwordDigest(password);
  accounts[key]={username:key,passwordHash:accountHash,profile};
  userAccounts=accounts;
  await chrome.storage.local.set({userAccounts:accounts});
  try{await authApi('set',{username:key,deviceId:freshId,passwordHash:accountHash})}catch(e){console.warn('account auth registration',e)}
  activeProfile='user';activeUsername=key;deviceId=freshId;balances={};activity=[];prefs={hideBalances:false,accountName:key};
  adminSession=false;premiumAccess=false;sharedReady=false;seenTransferIds.clear();pendingBalancePushes.clear();
  document.querySelector('.account-name').textContent='Account 1';renderHome();populateSecret();
  await persist();
  startOwnerHeartbeat();
}

function openAccount(){
  if(ownerSession){openSheet('Account',`<div class="account-card"><strong>Owner</strong><span>Owner account</span></div><button id="logoutAccount" class="secondary">Log out</button>`);$('logoutAccount').onclick=logoutWallet;return;}
  if(activeProfile==='admin'){
    openSheet('Account',`<div class="account-card"><strong>Admin</strong><span>Administrator account</span></div><button id="logoutAccount" class="secondary">Log out</button>`);
    $('logoutAccount').onclick=logoutWallet;
    return;
  }
  const current=activeUsername||prefs.accountName||'';
  openSheet('Account',`<div class="account-card"><strong>${esc(current)}</strong><span>Login username</span></div><div class="field"><label>Username</label><input id="accountNameInput" maxlength="20" value="${esc(current)}" autocomplete="off"></div><button id="saveAccountName" class="primary">Change username</button><button id="logoutAccount" class="secondary">Log out</button>`);
  $('saveAccountName').onclick=async()=>{
    const next=String($('accountNameInput').value||'').trim().toLowerCase();
    const old=activeUsername;
    if(!/^[a-z0-9_]{3,20}$/.test(next)){toast('Use 3–20 letters, numbers, or underscores');return}
    if(next==='admin'||next==='owner'){toast('Username is reserved');return}
    if(next===old){closeSheet();return}
    const btn=$('saveAccountName');btn.disabled=true;btn.textContent='Changing…';
    try{
      await renameUsernameRemote(old,next);
      const d=await chrome.storage.local.get('userAccounts');
      const accounts={...(d.userAccounts||{}),...userAccounts};
      if(accounts[next]&&next!==old)throw new Error('Username already exists on this device');
      const record=accounts[old];
      if(!record)throw new Error('Account record not found');
      delete accounts[old];
      activeUsername=next;
      prefs.accountName=next;
      accounts[next]={...record,username:next,profile:{...(record.profile||{}),prefs:{...((record.profile||{}).prefs||{}),accountName:next}}};
      userAccounts=accounts;
      await chrome.storage.local.set({userAccounts:accounts});
      document.querySelector('.account-name').textContent=next;
      await saveActiveProfile();
      toast('Username updated');
      closeSheet();
    }catch(e){
      toast(e?.message||'Could not change username');
      btn.disabled=false;btn.textContent='Change username';
    }
  };
  $('logoutAccount').onclick=logoutWallet;
}
async function openSearch(){openSheet('Search',`<input id="assetSearch" class="search-input" placeholder="Search any coin" autofocus><div id="assetSearchResults" class="asset-picker"></div>`);const input=$('assetSearch');let timer;input.oninput=()=>{clearTimeout(timer);timer=setTimeout(async()=>{const q=input.value.trim();const ids=q.length>=2?await searchCoins(q):Object.keys(coins).filter(id=>market[id]).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999)).slice(0,30);$('assetSearchResults').innerHTML=marketRows(ids,'searchcoin');document.querySelectorAll('[data-searchcoin]').forEach(b=>b.onclick=()=>openToken(b.dataset.searchcoin))},250)};input.dispatchEvent(new Event('input'));input.focus()}
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>({deposit:openReceive,send:openSend,swap:openSwap,buy:openBuy}[b.dataset.action])());
$('tokenList').onclick=e=>{const row=e.target.closest('.token-row');if(row)openToken(row.dataset.coin)};$('marketBanner').onclick=openExplore;$('accountBtn').onclick=openAccount;$('scanBtn').onclick=()=>openSheet('Scan',`<div class="account-card"><strong>QR scanner</strong><span>Camera access is not enabled in this extension.</span></div><div class="field"><label>Paste an address</label><input placeholder="Paste text or an address"></div>`);$('searchBtn').onclick=openSearch;
$('tokensTab').onclick=()=>{$('tokensTab').classList.add('active');$('nftsTab').classList.remove('active');$('tokenList').hidden=false;$('nftEmpty').hidden=true};$('nftsTab').onclick=()=>{$('nftsTab').classList.add('active');$('tokensTab').classList.remove('active');$('tokenList').hidden=true;$('nftEmpty').hidden=false};document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-nav]').forEach(x=>x.classList.remove('active'));b.classList.add('active');const n=b.dataset.nav;if(n==='home')closeSheet();if(n==='explore')openExplore();if(n==='swap')openSwap();if(n==='activity')openActivity();if(n==='settings')openSettings()});
function populateSecret(){const sel=$('coinSelect'),current=sel.value;const ids=[...new Set([...sortedHoldingIds(),...Object.keys(coins).filter(id=>market[id]).sort((a,b)=>(coins[a].rank||999999)-(coins[b].rank||999999)).slice(0,100)])];sel.innerHTML=ids.map(id=>`<option value="${esc(id)}">${esc(coin(id).name)} (${esc(coin(id).symbol)})</option>`).join('');if(current&&ids.includes(current))sel.value=current;updateSecret()}
function updateSecret(){const id=$('coinSelect').value;if(!id)return;$('amountSymbol').textContent=coin(id).symbol;$('usdPreview').textContent=fmtUSD((Number($('fakeAmount').value)||0)*price(id))}
$('coinSelect').onchange=updateSecret;$('fakeAmount').oninput=updateSecret;let secretSearchTimer;$('secretCoinSearch').oninput=()=>{clearTimeout(secretSearchTimer);secretSearchTimer=setTimeout(async()=>{const q=$('secretCoinSearch').value.trim();if(q.length<2)return;const ids=await searchCoins(q);const sel=$('coinSelect');sel.innerHTML=ids.map(id=>`<option value="${esc(id)}">${esc(coin(id).name)} (${esc(coin(id).symbol)})</option>`).join('');if(ids.length){sel.value=ids[0];updateSecret()}},250)};$('closeSecret').onclick=()=>$('secretOverlay').hidden=true;$('secretOverlay').onclick=e=>{if(e.target===$('secretOverlay'))$('secretOverlay').hidden=true};$('setFakeBalance').onclick=async()=>{if(!adminSession&&!ownerSession)return;const id=$('coinSelect').value;if(!id)return;const c=coin(id),old=Number(balances[id])||0;balances[id]=Math.max(0,Number($('fakeAmount').value)||0);const delta=balances[id]-old;if(delta>0){await logActivity('Received',id,delta,'Local balance');}else if(delta<0){await logActivity('Balance adjusted',id,delta,'Local balance');}await persist();if(sharedReady){try{await pushSharedBalances([id])}catch(e){console.warn(e)}}populateSecret();$('secretOverlay').hidden=true;if(delta>0){showReceiveToast(c,delta)}else{toast(`${c.symbol} balance updated`)}};$('resetFakeBalance').onclick=async()=>{if(!adminSession&&!ownerSession)return;const id=$('coinSelect').value;if(!id)return;balances[id]=0;await persist();if(sharedReady){try{await pushSharedBalances([id])}catch(e){console.warn(e)}}populateSecret();toast('Asset reset')};
document.addEventListener('keydown',e=>{const tag=document.activeElement?.tagName;if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='a'&&!['INPUT','TEXTAREA','SELECT'].includes(tag)){e.preventDefault();if(!adminSession&&!ownerSession)return; $('secretOverlay').hidden=false;populateSecret();$('fakeAmount').focus();$('fakeAmount').select()}if(e.key==='Escape'){if(!$('secretOverlay').hidden)$('secretOverlay').hidden=true;else closeSheet()}});

async function passwordDigest(value){
  const data=new TextEncoder().encode(value);
  const hash=await crypto.subtle.digest('SHA-256',data);
  return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');
}
function applyAccountAccess(){
  const buy=$('buyAction'),actions=document.querySelector('.quick-actions'),canBuy=hasBuyAccess();
  if(buy){buy.hidden=!canBuy;buy.classList.toggle('admin-hidden',!canBuy)}
  if(actions)actions.classList.toggle('no-buy',!canBuy);
  if(!adminSession&&!ownerSession&&$('secretOverlay'))$('secretOverlay').hidden=true;
  ensureOwnerBar();
}
function setupLocalLock(){
  const screen=$('lockScreen'),form=$('unlockForm'),input=$('unlockPassword'),usernameInput=$('unlockUsername'),error=$('unlockError');
  const createPanel=$('createAccountPanel'),createForm=$('createAccountForm'),newUser=$('newAccountUsername'),newPw=$('newAccountPassword'),confirmPw=$('confirmAccountPassword'),createError=$('createAccountError');
  if(!screen||!form||!input)return;
  adminSession=false;premiumAccess=false;ownerSession=false;ownerToken='';applyAccountAccess();
  const fail=(message='Incorrect username or password')=>{error.textContent=message;input.classList.remove('bad');void input.offsetWidth;input.classList.add('bad');input.select()};
  const unlock=async(admin=false,username='',owner=false)=>{
    await switchProfile(admin?'admin':'user',username);
    adminSession=admin||owner;
    ownerSession=owner;
    premiumAccess=false;
    if(owner){activeUsername='owner';prefs.accountName='Owner';document.querySelector('.account-name').textContent='Owner';applyAccountAccess();}
    else if(!admin)await refreshPremiumAccess();else applyAccountAccess();
    sessionUnlocked=true;startOwnerHeartbeat();
    screen.hidden=true;input.value='';error.textContent='';setTimeout(()=>input.classList.remove('bad'),250);
  };
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    const value=input.value,username=String(usernameInput?.value||'').trim().toLowerCase();
    if(!username){fail('Enter your username');return;}
    const stored=await chrome.storage.local.get(['adminPasswordHash']);
    const digest=await passwordDigest(value);
    const adminHash=stored.adminPasswordHash||DEFAULT_ADMIN_PASSWORD_HASH;
    if(username==='owner'){
      try{
        const d=await fetch(OWNER_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'login',key:value})}).then(async r=>{const x=await r.json();if(!r.ok||!x.ok)throw new Error(x.error||'Owner login failed');return x});
        ownerToken=d.token;
        await unlock(true,'admin',true);
      }catch(e){fail(e.message||'Invalid owner key')}
      return;
    }
    if(username==='admin'&&digest===adminHash){try{await unlock(true,'admin')}catch(e){fail(e.message)}return;}
    const accountsData=await chrome.storage.local.get('userAccounts');
    const accounts={...(accountsData.userAccounts||{})};
    let account=accounts[username];
    let remote=null;
    try{remote=await authApi('verify',{username,passwordHash:digest})}catch(e){console.warn('account auth verify',e)}
    if(remote?.exists){
      if(!remote.valid){fail();return;}
      if(!account){
        const profile={deviceId:remote.deviceId||newDeviceId(),balances:{},activity:[],prefs:{hideBalances:false,accountName:remote.displayUsername||username},ledgerBootstrapped:true};
        account={username,passwordHash:digest,profile};accounts[username]=account;userAccounts=accounts;await chrome.storage.local.set({userAccounts:accounts});
      }else if(account.passwordHash!==digest){account={...account,passwordHash:digest};accounts[username]=account;userAccounts=accounts;await chrome.storage.local.set({userAccounts:accounts});}
      try{await unlock(false,username)}catch(e){fail(e.message)}
      return;
    }
    if(!account){fail('Account not found');return;}
    if(digest===account.passwordHash){
      try{await authApi('set',{username,deviceId:account.profile?.deviceId||'',passwordHash:digest})}catch(e){console.warn('legacy auth migration',e)}
      try{await unlock(false,username)}catch(e){fail(e.message)}
    }else fail();
  });
  $('createAccountBtn')?.addEventListener('click',()=>{createError.textContent='';newUser.value='';newPw.value='';confirmPw.value='';createPanel.hidden=false;setTimeout(()=>newUser.focus(),30)});
  $('closeCreateAccount')?.addEventListener('click',()=>{createPanel.hidden=true;input.focus()});
  createPanel?.addEventListener('click',e=>{if(e.target===createPanel){createPanel.hidden=true;input.focus()}});
  createForm?.addEventListener('submit',async e=>{
    e.preventDefault();
    const username=String(newUser.value||'').trim().toLowerCase(),a=newPw.value,b=confirmPw.value;
    if(username==='admin'||username==='owner'){createError.textContent='Username is reserved';return;}
    if(!/^[a-z0-9_]{3,20}$/.test(username)){createError.textContent='Use 3–20 letters, numbers, or underscores';return;}
    if(a.length<4){createError.textContent='Use at least 4 characters';return;}
    if(a!==b){createError.textContent='Passwords do not match';return;}
    const adminStored=await chrome.storage.local.get('adminPasswordHash');
    if(await passwordDigest(a)===(adminStored.adminPasswordHash||DEFAULT_ADMIN_PASSWORD_HASH)){createError.textContent='Choose a different password';return;}
    createError.textContent='Creating wallet…';
    try{
      // Username checks are account-scoped. Generate the new wallet identity first
      // so the backend never receives an empty device/account id.
      const candidateDeviceId=newDeviceId();
      const availability=await ledger('checkUsername',{username,deviceId:candidateDeviceId});
      if(!availability.available){createError.textContent='Username is already taken';return;}
      await createFreshWalletAccount(a,username,candidateDeviceId);
      createPanel.hidden=true;
      createError.textContent='';
      await unlock(false,username);
      toast('New wallet created');
    }catch(err){
      console.error(err);createError.textContent=err?.message||'Could not create wallet';
    }
  });
  $('forgotPassword')?.addEventListener('click',async()=>{const {userAccounts}=await chrome.storage.local.get('userAccounts');error.textContent=Object.keys(userAccounts||{}).length?'There is no password recovery for local accounts':'No local account created yet';input.focus()});
  $('lockHelp')?.addEventListener('click',()=>{error.textContent='Enter your username and password';usernameInput?.focus()});
  screen.hidden=false;
  setTimeout(()=>usernameInput?.focus(),30);
}
initReady=init();
setupLocalLock();
