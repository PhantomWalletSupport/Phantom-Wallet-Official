# Wallet Companion

A local, simulated browser-extension wallet UI for demos and pranks. It does not create, hold, transfer, sign, or represent real cryptocurrency.

## Hidden display controls
Press Cmd+A on macOS or Ctrl+A on Windows/Linux while focus is not inside a form field. Select SOL, BTC, ETH, or USDC and set a local simulated amount. The total and token list update from fixed display-only prices.

## Install
1. Unzip this folder.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Click Load unpacked and choose this folder.

Never enter a recovery phrase or private key.

## Account storage update
Normal accounts are now stored independently by username. Each account keeps its own wallet ID, balances, activity, preferences/account name, and receiving addresses. Existing single-user data is migrated into the username-based account registry automatically when possible.
