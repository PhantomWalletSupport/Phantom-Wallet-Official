"use strict";

const CACHE_KEY = "rtV2ItemDatabaseV800";
const CACHE_TIME_KEY = "rtV2ItemDatabaseV800At";
const CACHE_MS = 2 * 60 * 1000;
const LAST_SALE_CACHE_MS = 30 * 1000;


function normalizeRolimonsRecord(record) {
  if (!Array.isArray(record)) return null;
  const normalized = [...record];
  const rap = Number(normalized[2]) > 0 ? Number(normalized[2]) : 0;
  const assignedValue = Number(normalized[3]) > 0 ? Number(normalized[3]) : null;
  // Single source of truth used everywhere in the extension:
  // assigned Rolimon's Value when present, otherwise Value is exactly RAP.
  normalized[2] = rap;
  normalized[3] = assignedValue || rap;
  normalized._assignedValue = assignedValue;
  return normalized;
}

function normalizeRolimonsItems(items) {
  const out = {};
  for (const [assetId, record] of Object.entries(items || {})) {
    const normalized = normalizeRolimonsRecord(record);
    if (normalized) out[String(assetId)] = normalized;
  }
  return out;
}

let memoryItems = null;
let memoryFetchedAt = 0;
const lastSaleCache = new Map();

async function fetchRolimonsItems() {
  const now = Date.now();

  if (memoryItems && now - memoryFetchedAt < CACHE_MS) {
    return memoryItems;
  }

  const stored = await chrome.storage.local.get([CACHE_KEY, CACHE_TIME_KEY]);
  const storedAt = Number(stored[CACHE_TIME_KEY] || 0);

  if (stored[CACHE_KEY]) {
    memoryItems = stored[CACHE_KEY];
    memoryFetchedAt = storedAt || now;
    // Return cached itemdetails immediately so trade/counter values paint at
    // once. Refresh stale data in the background without blocking the UI.
    if (now - storedAt >= CACHE_MS) {
      fetch("https://www.rolimons.com/itemapi/itemdetails", {
        method: "GET", credentials: "omit", cache: "no-store"
      }).then((r) => r.ok ? r.json() : null).then((payload) => {
        if (!payload?.items || typeof payload.items !== "object") return;
        memoryItems = normalizeRolimonsItems(payload.items);
        memoryFetchedAt = Date.now();
        chrome.storage.local.set({ [CACHE_KEY]: memoryItems, [CACHE_TIME_KEY]: memoryFetchedAt });
      }).catch(() => {});
    }
    return memoryItems;
  }

  const response = await fetch("https://www.rolimons.com/itemapi/itemdetails", {
    method: "GET",
    credentials: "omit",
    cache: "no-store"
  });

  if (!response.ok) {
    throw new Error(`Rolimon's request failed (${response.status}).`);
  }

  const payload = await response.json();
  if (!payload?.items || typeof payload.items !== "object") {
    throw new Error("Rolimon's returned an unexpected item response.");
  }

  memoryItems = normalizeRolimonsItems(payload.items);
  memoryFetchedAt = now;

  await chrome.storage.local.set({
    [CACHE_KEY]: memoryItems,
    [CACHE_TIME_KEY]: memoryFetchedAt
  });

  return memoryItems;
}



function normalizeItemName(value) {
  return String(value || "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[’‘`]/g, "'")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

let itemNameIndexSource = null;
let itemNameIndex = new Map();

function getItemNameIndex(items) {
  if (itemNameIndexSource === items) return itemNameIndex;
  const next = new Map();
  for (const [assetId, record] of Object.entries(items || {})) {
    if (!Array.isArray(record)) continue;
    const normalized = normalizeItemName(record[0]);
    if (!normalized) continue;
    const list = next.get(normalized) || [];
    list.push({ assetId: String(assetId), record });
    next.set(normalized, list);
  }
  itemNameIndexSource = items;
  itemNameIndex = next;
  return next;
}

function candidateScore(candidate, requestedId, expectedRap) {
  const record = candidate.record || [];
  const rap = Number(record[2]) || 0;
  const value = Number(record[3]) || 0;
  let score = 0;
  if (candidate.assetId === requestedId) score += 1_000_000;
  if (rap > 0) score += 10_000;
  if (value > 0) score += 1_000;
  if (expectedRap > 0 && rap > 0) {
    const ratio = Math.max(rap, expectedRap) / Math.max(1, Math.min(rap, expectedRap));
    score += Math.max(0, 5000 - Math.log(ratio) * 2500);
  }
  return score;
}

async function resolveRolimonsItem({ assetId, name, rap } = {}) {
  const items = await fetchRolimonsItems();
  const requestedId = /^\d+$/.test(String(assetId || "")) ? String(assetId) : "";
  const normalizedName = normalizeItemName(name);
  const expectedRap = Number(rap) > 0 ? Number(rap) : 0;
  const direct = requestedId ? items?.[requestedId] : null;

  // Trust an ID only when no name is available or the database confirms the
  // displayed name. This prevents collectible-instance IDs from resolving to
  // unrelated catalog entries.
  if (Array.isArray(direct) && (!normalizedName || normalizeItemName(direct[0]) === normalizedName)) {
    return { assetId: requestedId, record: normalizeRolimonsRecord(direct), matchedBy: "assetId" };
  }

  if (normalizedName) {
    const candidates = [...(getItemNameIndex(items).get(normalizedName) || [])];
    candidates.sort((a, b) => candidateScore(b, requestedId, expectedRap) - candidateScore(a, requestedId, expectedRap));
    if (candidates[0]) return { ...candidates[0], record: normalizeRolimonsRecord(candidates[0].record), matchedBy: "name" };
  }

  // Newer Roblox limiteds can appear on Rolimon's exact item/sales pages before
  // they are present in the bulk itemdetails feed. Probe the exact asset ID and
  // build a compatible record from the live page instead of reporting a false
  // database miss. This is especially important for Limited 2.0 items.
  if (requestedId) {
    try {
      const live = await fetchLiveRolimonsItemStats(requestedId);
      if (live && (Number(live.rap) > 0 || Number(live.value) > 0)) {
        const safeName = String(name || `Item ${requestedId}`).trim();
        const liveAssignedValue = live.valueStatus === "unassigned"
          ? -1
          : (Number(live.value) > 0 ? Number(live.value) : -1);
        const synthetic = [
          safeName,
          "",
          Number(live.rap) || 0,
          liveAssignedValue,
          Number(live.rap) || 0,
          -1, -1, -1, -1, -1
        ];
        return { assetId: requestedId, record: normalizeRolimonsRecord(synthetic), matchedBy: "live-assetId" };
      }
    } catch (_) {
      // Continue to the final fallback/error below.
    }
  }

  // Last resort: retain a valid direct record rather than failing completely.
  if (Array.isArray(direct)) return { assetId: requestedId, record: normalizeRolimonsRecord(direct), matchedBy: "assetId-fallback" };
  throw new Error("This item could not be matched to Rolimon's item database or exact item page.");
}

async function resolveRolimonsItemsBatch(requests, options = {}) {
  // Resolve common trade-composer items from the cached bulk itemdetails feed
  // first. Only true misses use the slower exact Rolimon's page fallback.
  const items = await fetchRolimonsItems();
  const index = getItemNameIndex(items);
  const input = requests || [];
  const results = {};
  const misses = [];

  input.forEach((request, requestIndex) => {
    const requestedId = /^\d+$/.test(String(request?.assetId || "")) ? String(request.assetId) : "";
    const wanted = normalizeItemName(request?.name);
    const expectedRap = Number(request?.rap) > 0 ? Number(request.rap) : 0;
    const direct = requestedId ? items?.[requestedId] : null;
    let resolved = null;

    if (Array.isArray(direct) && (!wanted || normalizeItemName(direct[0]) === wanted)) {
      resolved = { assetId: requestedId, record: normalizeRolimonsRecord(direct), matchedBy: "assetId" };
    } else if (wanted) {
      const candidates = [...(index.get(wanted) || [])];
      candidates.sort((a, b) => candidateScore(b, requestedId, expectedRap) - candidateScore(a, requestedId, expectedRap));
      if (candidates[0]) resolved = { ...candidates[0], record: normalizeRolimonsRecord(candidates[0].record), matchedBy: "name" };
    }

    if (resolved) results[String(requestIndex)] = { ok: true, ...resolved };
    else misses.push({ request, requestIndex });
  });

  // Counter/send pages should not block all visible cards on slow exact-page
  // probes. With the clean Roblox item-name node, ordinary catalog items resolve
  // from cached itemdetails immediately. True misses retain their visible RAP
  // fallback in content.js rather than turning the whole grid into a spinner.
  if (options.fastOnly) {
    for (const { requestIndex } of misses) {
      results[String(requestIndex)] = { ok: false, error: "Not present in cached itemdetails." };
    }
    return results;
  }

  await Promise.all(misses.map(async ({ request, requestIndex }) => {
    try {
      const resolved = await resolveRolimonsItem(request);
      results[String(requestIndex)] = { ok: true, ...resolved };
    } catch (error) {
      results[String(requestIndex)] = { ok: false, error: error?.message || String(error) };
    }
  }));

  return results;
}

function htmlToText(html) {
  return String(html || "")
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/\s+/g, " ")
    .trim();
}

async function fetchLastSale(assetId) {
  if (!/^\d+$/.test(String(assetId))) {
    throw new Error("Invalid asset ID.");
  }

  const key = String(assetId);
  const now = Date.now();
  const cached = lastSaleCache.get(key);

  if (cached && now - cached.fetchedAt < LAST_SALE_CACHE_MS) {
    return cached.salePrice;
  }

  const url = `https://www.rolimons.com/itemsales/${encodeURIComponent(key)}`;
  const response = await fetch(url, {
    method: "GET",
    credentials: "omit",
    cache: "no-store",
    headers: {
      "Accept": "text/html,application/xhtml+xml"
    }
  });

  if (!response.ok) {
    throw new Error(`Rolimon's sales request failed (${response.status}).`);
  }

  const html = await response.text();
  const text = htmlToText(html);
  const salesStart = text.indexOf("Sales List");
  const salesText = salesStart >= 0 ? text.slice(salesStart) : text;
  const match = salesText.match(/Sale Price\s+([0-9][0-9,]*)/i);

  if (!match) {
    throw new Error("No tracked sale was found for this item.");
  }

  const salePrice = Number(match[1].replace(/,/g, ""));
  if (!Number.isFinite(salePrice) || salePrice < 0) {
    throw new Error("Rolimon's returned an invalid sale price.");
  }

  lastSaleCache.set(key, { salePrice, fetchedAt: now });
  return salePrice;
}


const liveItemStatsCache = new Map();
const LIVE_ITEM_STATS_CACHE_MS = 30 * 1000;

function parseLiveRolimonsStats(html, assetId) {
  const text = htmlToText(html);

  // Rolimon's item pages embed an authoritative item_details_data object.
  // In that object, value:null explicitly means the item has no assigned
  // value and its effective trading value should be 1:1 with RAP. Preserve
  // that distinction so later HTML or bulk-feed fallbacks cannot turn an
  // unrelated number (commonly 2,000) into Value.
  let embeddedItemDetails = null;
  const embeddedMatch = String(html || "").match(/var\s+item_details_data\s*=\s*(\{[\s\S]*?\});/i);
  if (embeddedMatch) {
    try { embeddedItemDetails = JSON.parse(embeddedMatch[1]); } catch (_) {}
  }
  const summaryEnd = text.search(/\bSales Chart\b|\bSales List\b|\bOwnership\b/i);
  const summary = summaryEnd > 0 ? text.slice(0, summaryEnd) : text.slice(0, 8000);

  const number = (value) => {
    const parsed = Number(String(value || "").replace(/,/g, ""));
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
  };

  // Read a value only from the same summary field as its label. Rolimon's may
  // render "Not Assigned" for Value. A broad "first number after the label"
  // lookup can then drift into the next card and accidentally return Sellers
  // (for example, Value = 7 and Sellers = 7). Stop at the next known field and
  // treat an explicit unassigned marker as null.
  const summaryLabels = [
    "Best Price", "Last Sale", "Current RAP", "RAP", "Current Value",
    "Assigned Value", "Value", "Demand", "Trend", "Sellers",
    "Tracked Sales", "All Tracked Sales", "Past Day Sales",
    "Past Week Sales", "Past Month Sales"
  ];

  const readSummaryField = (labels) => {
    const lower = summary.toLowerCase();
    for (const label of labels) {
      const labelText = String(label);
      const index = lower.indexOf(labelText.toLowerCase());
      if (index < 0) continue;

      const start = index + labelText.length;
      let end = Math.min(summary.length, start + 100);
      for (const nextLabel of summaryLabels) {
        const nextIndex = lower.indexOf(nextLabel.toLowerCase(), start);
        if (nextIndex >= start && nextIndex < end) end = nextIndex;
      }

      const fieldText = summary.slice(start, end).trim();
      if (/^(?:not\s+assigned|unassigned|n\/?a|none)\b/i.test(fieldText)) return null;

      const match = fieldText.match(/^(?:[:\-–—]\s*)?(?:R\$|Robux)?\s*([0-9][0-9,]*)\b/i);
      if (!match) continue;
      const parsed = number(match[1]);
      if (parsed !== null) return parsed;
    }
    return null;
  };

  const readSummaryTextField = (labels) => {
    const lower = summary.toLowerCase();
    for (const label of labels) {
      const labelText = String(label);
      const index = lower.indexOf(labelText.toLowerCase());
      if (index < 0) continue;

      const start = index + labelText.length;
      let end = Math.min(summary.length, start + 100);
      for (const nextLabel of summaryLabels) {
        const nextIndex = lower.indexOf(nextLabel.toLowerCase(), start);
        if (nextIndex >= start && nextIndex < end) end = nextIndex;
      }

      const fieldText = summary.slice(start, end)
        .replace(/^\s*[:\-–—]\s*/, "")
        .split(/\n|\r/)[0]
        .trim();
      if (fieldText) return fieldText;
    }
    return null;
  };

  const normalizeDemand = (value) => {
    if (value == null || value === "") return null;
    const numeric = Number(value);
    if (Number.isInteger(numeric) && numeric >= -1 && numeric <= 4) return numeric;
    const key = String(value).trim().toLowerCase();
    return ({
      "not assigned": -1, unassigned: -1, none: -1, "n/a": -1,
      terrible: 0, low: 1, normal: 2, high: 3, amazing: 4
    })[key] ?? null;
  };

  const normalizeTrend = (value) => {
    if (value == null || value === "") return null;
    const numeric = Number(value);
    if (Number.isInteger(numeric) && numeric >= -1 && numeric <= 4) return numeric;
    const key = String(value).trim().toLowerCase();
    return ({
      "not assigned": -1, unassigned: -1, none: -1, "n/a": -1,
      lowering: 0, unstable: 1, stable: 2, raising: 3, fluctuating: 4
    })[key] ?? null;
  };

  const readRawHtmlField = (labels) => {
    for (const label of labels) {
      const escaped = String(label).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      // Keep the match tightly scoped to the labelled summary card. This works
      // when Rolimon's visually separates the label and number with HTML tags.
      const pattern = new RegExp(escaped + "[\\s\\S]{0,350}?([0-9][0-9,]{2,})", "i");
      const match = String(html || "").match(pattern);
      if (match) {
        const parsed = number(match[1]);
        if (parsed !== null) return parsed;
      }
    }
    return null;
  };

  const readEmbeddedNumber = (keys) => {
    for (const key of keys) {
      const escaped = String(key).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const patterns = [
        new RegExp('["\\\']' + escaped + '["\\\']\\s*:\s*([0-9]+)', 'i'),
        new RegExp('\\b' + escaped + '\\b\\s*[:=]\\s*([0-9]+)', 'i')
      ];
      for (const pattern of patterns) {
        const match = String(html || "").match(pattern);
        if (match) {
          const parsed = number(match[1]);
          if (parsed !== null) return parsed;
        }
      }
    }
    return null;
  };

  const bestPriceCandidates = [
    number(embeddedItemDetails?.best_price),
    readSummaryField(["Best Price"]),
    readRawHtmlField(["Best Price"])
  ];
  const bestPrice = bestPriceCandidates.find((candidate) => Number(candidate) > 0) ?? null;
  const rap = number(embeddedItemDetails?.rap)
    ?? readSummaryField(["Current RAP", "RAP"])
    ?? readEmbeddedNumber(["rap", "current_rap", "currentRap"])
    ?? readRawHtmlField(["Current RAP", "RAP"]);

  const embeddedHasValueField = embeddedItemDetails
    && Object.prototype.hasOwnProperty.call(embeddedItemDetails, "value");
  const embeddedAssignedValue = embeddedHasValueField
    ? number(embeddedItemDetails.value)
    : null;
  const explicitlyUnassigned = embeddedHasValueField
    && !(embeddedAssignedValue > 0);

  const value = embeddedAssignedValue > 0
    ? embeddedAssignedValue
    : (explicitlyUnassigned
      ? null
      : (readSummaryField(["Current Value", "Assigned Value", "Value"])
        ?? readEmbeddedNumber(["value", "item_value", "itemValue", "assigned_value", "assignedValue"])
        ?? readRawHtmlField(["Current Value", "Assigned Value"])));

  const demand = normalizeDemand(embeddedItemDetails?.demand)
    ?? normalizeDemand(readSummaryTextField(["Demand"]));
  const trend = normalizeTrend(embeddedItemDetails?.trend)
    ?? normalizeTrend(readSummaryTextField(["Trend"]));

  if (!(rap > 0) && !(value > 0)) {
    throw new Error(`Rolimon's page did not contain RAP/value for asset ${assetId}.`);
  }

  return {
    assetId: String(assetId),
    rap: rap || 0,
    value: value > 0 ? value : null,
    valueStatus: value > 0 ? "assigned" : (explicitlyUnassigned ? "unassigned" : "unknown"),
    bestPrice,
    demand,
    trend,
    fetchedAt: Date.now()
  };
}

async function fetchLiveRolimonsItemStats(assetId) {
  const key = String(assetId || "");
  if (!/^\d+$/.test(key)) throw new Error("Invalid asset ID.");

  const now = Date.now();
  const cached = liveItemStatsCache.get(key);
  if (cached && now - cached.fetchedAt < LIVE_ITEM_STATS_CACHE_MS) return cached.value;

  const fetchPage = async (url) => {
    const response = await fetch(url, {
      method: "GET",
      credentials: "omit",
      cache: "no-store",
      headers: { "Accept": "text/html,application/xhtml+xml" }
    });
    if (!response.ok) throw new Error(`Rolimon's item request failed (${response.status}).`);
    return response.text();
  };

  const salesHtml = await fetchPage(`https://www.rolimons.com/itemsales/${encodeURIComponent(key)}`);
  let stats = parseLiveRolimonsStats(salesHtml, key);

  // Some Rolimon's deployments omit one summary field from the sales page.
  // Fill only missing fields from the exact item profile; never replace a
  // successfully parsed live sales-page value with bulk-database data.
  if (!(stats.value > 0) || !(stats.bestPrice > 0) || !(stats.rap > 0) || stats.demand == null || stats.trend == null) {
    try {
      const profileStats = parseLiveRolimonsStats(
        await fetchPage(`https://www.rolimons.com/item/${encodeURIComponent(key)}`),
        key
      );
      const profileSaysUnassigned = profileStats.valueStatus === "unassigned";
      stats = {
        ...stats,
        rap: stats.rap > 0 ? stats.rap : profileStats.rap,
        // The exact item profile's embedded value:null is authoritative. It
        // must override numbers such as "Value Sold 2,000" on sales pages.
        value: profileSaysUnassigned ? null : (stats.value > 0 ? stats.value : profileStats.value),
        valueStatus: profileSaysUnassigned
          ? "unassigned"
          : (stats.value > 0 ? "assigned" : (profileStats.valueStatus || stats.valueStatus)),
        bestPrice: stats.bestPrice > 0 ? stats.bestPrice : profileStats.bestPrice,
        demand: stats.demand != null ? stats.demand : profileStats.demand,
        trend: stats.trend != null ? stats.trend : profileStats.trend
      };
    } catch (_) {
      // The sales-page result remains usable even if the profile fallback fails.
    }
  }

  // The live page may say "Not Assigned" or temporarily omit Value while
  // Rolimon's bulk item feed already contains the assigned value. Prefer that
  // exact asset record before falling back to RAP.
  if (!(stats.value > 0) && stats.valueStatus !== "unassigned") {
    try {
      const record = (await fetchRolimonsItems())?.[key];
      // In Rolimon's itemdetails, index 3 is the assigned Value. Index 4 is
      // a default/base field and is commonly 2,000 for unassigned items; it
      // must never be displayed as the trading Value.
      const assigned = Number(record?.[3]) > 0 ? Number(record[3]) : 0;
      if (assigned > 0 && assigned !== Number(stats.rap || 0)) stats.value = assigned;
    } catch (_) {
      // Leave Value unassigned; callers will use RAP as the display fallback.
    }
  }

  liveItemStatsCache.set(key, { value: stats, fetchedAt: now });
  return stats;
}

async function fetchLiveRolimonsStatsBatch(assetIds) {
  const ids = [...new Set((assetIds || []).map(String).filter((id) => /^\d+$/.test(id)))];
  const entries = await Promise.all(ids.map(async (id) => {
    try { return [id, await fetchLiveRolimonsItemStats(id)]; }
    catch (error) { return [id, { assetId: id, error: error?.message || String(error) }]; }
  }));
  return Object.fromEntries(entries);
}


const thumbnailCache = new Map();
const THUMBNAIL_CACHE_MS = 10 * 60 * 1000;

async function fetchRobloxThumbnails(assetIds) {
  const ids = [...new Set((assetIds || []).map(String).filter((id) => /^\d+$/.test(id)))];
  const images = {};
  const now = Date.now();
  const missing = [];
  for (const id of ids) {
    const cached = thumbnailCache.get(id);
    if (cached && now - cached.fetchedAt < THUMBNAIL_CACHE_MS) images[id] = cached.imageUrl;
    else missing.push(id);
  }
  for (let i = 0; i < missing.length; i += 50) {
    const chunk = missing.slice(i, i + 50);
    const params = new URLSearchParams({ assetIds: chunk.join(','), returnPolicy: 'PlaceHolder', size: '420x420', format: 'Png', isCircular: 'false' });
    const response = await fetch(`https://thumbnails.roblox.com/v1/assets?${params}`, { credentials: 'omit', cache: 'no-store' });
    if (!response.ok) throw new Error(`Roblox thumbnail request failed (${response.status}).`);
    const payload = await response.json();
    for (const entry of payload?.data || []) {
      const id = String(entry?.targetId ?? '');
      const imageUrl = typeof entry?.imageUrl === 'string' ? entry.imageUrl : '';
      if (id && imageUrl) { images[id] = imageUrl; thumbnailCache.set(id, { imageUrl, fetchedAt: now }); }
    }
  }
  return images;
}


const holdingInfoCache = new Map();
const HOLDING_INFO_CACHE_MS = 60 * 1000;
const ROBLOX_HOLD_MS = 2 * 24 * 60 * 60 * 1000;

function walkObjects(value, visit) {
  if (!value || typeof value !== "object") return;
  visit(value);
  if (Array.isArray(value)) {
    for (const item of value) walkObjects(item, visit);
  } else {
    for (const item of Object.values(value)) walkObjects(item, visit);
  }
}

function numberFromKeys(object, keys) {
  for (const key of keys) {
    const value = object?.[key];
    if (value !== undefined && value !== null && /^\d+$/.test(String(value))) return String(value);
  }
  return null;
}

function dateFromKeys(object, keys) {
  for (const key of keys) {
    const value = object?.[key];
    if (value === undefined || value === null) continue;
    const timestamp = typeof value === "number" && value < 1e12 ? value * 1000 : Date.parse(String(value));
    if (Number.isFinite(timestamp)) return timestamp;
  }
  return null;
}

async function getAuthenticatedUserId() {
  const response = await fetch("https://users.roblox.com/v1/users/authenticated", {
    credentials: "include",
    cache: "no-store"
  });
  if (!response.ok) throw new Error(`Roblox user request failed (${response.status}).`);
  const payload = await response.json();
  const id = String(payload?.id || "");
  if (!/^\d+$/.test(id)) throw new Error("Could not identify the authenticated Roblox user.");
  return id;
}

async function fetchOwnedCopies(userId, assetId) {
  let resolvedUserId = String(userId || "");
  if (resolvedUserId === "me") resolvedUserId = await getAuthenticatedUserId();
  if (!/^\d+$/.test(resolvedUserId) || !/^\d+$/.test(String(assetId))) return [];

  const copies = [];
  let cursor = "";
  let pages = 0;

  do {
    const params = new URLSearchParams({
      sortOrder: "Asc",
      limit: "100"
    });
    if (cursor) params.set("cursor", cursor);

    const response = await fetch(
      `https://inventory.roblox.com/v1/users/${resolvedUserId}/assets/collectibles?${params}`,
      { credentials: "include", cache: "no-store" }
    );

    if (!response.ok) {
      throw new Error(`Roblox collectibles request failed (${response.status}).`);
    }

    const payload = await response.json();
    for (const object of payload?.data || []) {
      const foundAssetId = numberFromKeys(object, ["assetId", "id", "targetId"]);
      if (foundAssetId !== String(assetId)) continue;

      const uaid = numberFromKeys(object, [
        "userAssetId",
        "userAssetID",
        "uaid",
        "collectibleItemInstanceId",
        "instanceId"
      ]);
      const serial = numberFromKeys(object, ["serialNumber", "serial", "serialId"]);
      const holdUntil = dateFromKeys(object, [
        "holdUntil",
        "holdingUntil",
        "tradableAfter",
        "tradableAt",
        "availableAt",
        "expirationTime",
        "expiresAt"
      ]);

      if (uaid || holdUntil) copies.push({ uaid, serial, holdUntil });
    }

    cursor = String(payload?.nextPageCursor || "");
    pages += 1;
  } while (cursor && pages < 20 && copies.length === 0);

  return copies;
}

function parseRolimonsDate(value) {
  const text = String(value || "").trim();
  const iso = Date.parse(text);
  if (Number.isFinite(iso)) return iso;

  // Rolimon's commonly renders: 2026-7-20 07:31:17 PM
  const match = text.match(/(20\d{2})-(\d{1,2})-(\d{1,2})\s+(\d{1,2}):(\d{2}):(\d{2})\s*(AM|PM)?/i);
  if (!match) return null;
  let hour = Number(match[4]);
  const meridiem = String(match[7] || "").toUpperCase();
  if (meridiem === "PM" && hour < 12) hour += 12;
  if (meridiem === "AM" && hour === 12) hour = 0;
  const timestamp = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), hour, Number(match[5]), Number(match[6])).getTime();
  return Number.isFinite(timestamp) ? timestamp : null;
}

function parseRolimonsOwnerUpdated(html) {
  const text = htmlToText(html);
  const recordedIndex = text.indexOf("Recorded Owners");
  const scope = recordedIndex >= 0 ? text.slice(recordedIndex, recordedIndex + 5000) : text;
  const patterns = [
    // Rolimon's UAID pages label the current-copy acquisition timestamp as
    // "Owner Since". Keep the older labels as fallbacks for page variants.
    /Owner Since\s+(?:[^0-9]{0,120})?(20\d{2}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2}:\d{2}\s*(?:AM|PM)?)/i,
    /Owner Updated\s+(?:[^0-9]{0,120})?(20\d{2}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2}:\d{2}\s*(?:AM|PM)?)/i,
    /Owned Since\s+(?:[^0-9]{0,120})?(20\d{2}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2}:\d{2}\s*(?:AM|PM)?)/i,
    /(20\d{2}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z)/i
  ];
  for (const pattern of patterns) {
    const match = scope.match(pattern) || text.match(pattern);
    if (!match) continue;
    const timestamp = parseRolimonsDate(match[1]);
    if (Number.isFinite(timestamp)) return timestamp;
  }
  return null;
}


function parseRelativeAgeMilliseconds(value) {
  const text = String(value || "").trim().toLowerCase();
  const match = text.match(/(\d+(?:\.\d+)?)\s*(second|minute|hour|day|week|month|year)s?\s+ago/);
  if (!match) return null;
  const amount = Number(match[1]);
  const unit = match[2];
  const multipliers = {
    second: 1000,
    minute: 60 * 1000,
    hour: 60 * 60 * 1000,
    day: 24 * 60 * 60 * 1000,
    week: 7 * 24 * 60 * 60 * 1000,
    month: 30 * 24 * 60 * 60 * 1000,
    year: 365 * 24 * 60 * 60 * 1000
  };
  return Number.isFinite(amount) ? amount * multipliers[unit] : null;
}


async function resolveRobloxUserId(userId) {
  const raw = String(userId || "").trim();
  if (/^\d+$/.test(raw)) return raw;
  if (raw !== "me") return null;

  const response = await fetch("https://users.roblox.com/v1/users/authenticated", {
    credentials: "include",
    cache: "no-store",
    headers: { "Accept": "application/json" }
  });
  if (!response.ok) return null;
  const payload = await response.json();
  const id = String(payload?.id || "");
  return /^\d+$/.test(id) ? id : null;
}

async function fetchRolimonsPlayerHoldUntil(userId, assetId, serial) {
  if (!/^\d+$/.test(String(userId)) || !/^\d+$/.test(String(assetId))) return null;
  const response = await fetch(`https://www.rolimons.com/player/${encodeURIComponent(String(userId))}`, {
    credentials: "omit",
    cache: "no-store",
    headers: { "Accept": "text/html,application/xhtml+xml" }
  });
  if (!response.ok) return null;
  const html = await response.text();

  const itemPatterns = [
    new RegExp(`/item/${String(assetId)}(?:[^0-9]|$)`, "ig"),
    new RegExp(`(?:asset[_-]?id|item[_-]?id)[^0-9]{0,20}${String(assetId)}(?:[^0-9]|$)`, "ig")
  ];
  const windows = [];
  for (const pattern of itemPatterns) {
    let match;
    while ((match = pattern.exec(html)) && windows.length < 30) {
      windows.push(html.slice(Math.max(0, match.index - 2500), Math.min(html.length, match.index + 5000)));
    }
  }
  if (!windows.length) return null;

  let candidates = windows;
  if (serial) {
    const serialPattern = new RegExp(`(?:Serial\s*#?|#)\s*${String(serial)}(?:[^0-9]|$)`, "i");
    const serialWindows = windows.filter((block) => serialPattern.test(htmlToText(block)));
    if (serialWindows.length) candidates = serialWindows;
  }

  for (const block of candidates) {
    const text = htmlToText(block);
    const relative = text.match(/Owner Since\s+((?:\d+(?:\.\d+)?\s*)?(?:second|minute|hour|day|week|month|year)s?\s+ago)/i);
    if (relative) {
      const elapsed = parseRelativeAgeMilliseconds(relative[1]);
      if (Number.isFinite(elapsed)) return Date.now() - elapsed + ROBLOX_HOLD_MS;
    }
    const absolute = text.match(/Owner Since\s+(20\d{2}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2}:\d{2}\s*(?:AM|PM)?)/i);
    if (absolute) {
      const acquiredAt = parseRolimonsDate(absolute[1]);
      if (Number.isFinite(acquiredAt)) return acquiredAt + ROBLOX_HOLD_MS;
    }
  }
  return null;
}

async function fetchAssetOwnerCopies(userId, assetId, serial) {
  if (!/^\d+$/.test(String(userId)) || !/^\d+$/.test(String(assetId))) return [];
  const matches = [];
  let cursor = "";
  let pages = 0;
  do {
    const params = new URLSearchParams({ sortOrder: "Asc", limit: "100" });
    if (cursor) params.set("cursor", cursor);
    const response = await fetch(`https://inventory.roblox.com/v2/assets/${encodeURIComponent(String(assetId))}/owners?${params}`, {
      credentials: "omit",
      cache: "no-store"
    });
    if (!response.ok) break;
    const payload = await response.json();
    for (const object of payload?.data || []) {
      const ownerId = numberFromKeys(object?.owner || object, ["id", "userId", "ownerId"]);
      if (String(ownerId || "") !== String(userId)) continue;
      const foundSerial = numberFromKeys(object, ["serialNumber", "serial", "serialId"]);
      if (serial && foundSerial && String(foundSerial) !== String(serial)) continue;
      const uaid = numberFromKeys(object, ["userAssetId", "uaid", "collectibleItemInstanceId", "instanceId"]);
      if (uaid) matches.push({ uaid, serial: foundSerial, holdUntil: null });
    }
    if (matches.length) break;
    cursor = String(payload?.nextPageCursor || "");
    pages += 1;
  } while (cursor && pages < 50);
  return matches;
}

async function fetchRolimonsHoldUntil(uaid) {
  if (!/^\d+$/.test(String(uaid))) return null;
  const response = await fetch(`https://www.rolimons.com/uaid/${encodeURIComponent(String(uaid))}`, {
    credentials: "omit",
    cache: "no-store",
    headers: { "Accept": "text/html,application/xhtml+xml" }
  });
  if (!response.ok) throw new Error(`Rolimon's UAID request failed (${response.status}).`);
  const acquiredAt = parseRolimonsOwnerUpdated(await response.text());
  return acquiredAt ? acquiredAt + ROBLOX_HOLD_MS : null;
}

async function fetchHoldingInfo({ userId, assetId, serial, uaid }) {
  const resolvedUserId = await resolveRobloxUserId(userId);
  const key = `${resolvedUserId || userId || ""}:${assetId || ""}:${serial || ""}:${uaid || ""}`;
  const now = Date.now();
  const cached = holdingInfoCache.get(key);
  if (cached && now - cached.fetchedAt < HOLDING_INFO_CACHE_MS) return cached.value;

  let directHoldUntil = null;
  if (/^\d{6,}$/.test(String(uaid || ""))) {
    try { directHoldUntil = await fetchRolimonsHoldUntil(String(uaid)); } catch (_) { /* continue */ }
  }

  // Rolimon's player inventory already exposes Owner Since for the exact item.
  // This is the most useful fallback when Roblox no longer returns a UAID.
  if (!directHoldUntil && resolvedUserId) {
    try { directHoldUntil = await fetchRolimonsPlayerHoldUntil(resolvedUserId, String(assetId), serial); } catch (_) { /* continue */ }
  }

  let copies = directHoldUntil || !resolvedUserId ? [] : await fetchOwnedCopies(resolvedUserId, assetId);
  if (!directHoldUntil && resolvedUserId && !copies.some((entry) => entry.uaid)) {
    try { copies = copies.concat(await fetchAssetOwnerCopies(resolvedUserId, String(assetId), serial)); } catch (_) { /* continue */ }
  }

  let copy = null;
  if (serial) copy = copies.find((entry) => String(entry.serial || "") === String(serial));
  if (!copy) copy = copies.find((entry) => entry.holdUntil && entry.holdUntil > now) || copies.find((entry) => entry.uaid) || copies[0] || null;

  let holdUntil = directHoldUntil || copy?.holdUntil || null;
  if (!holdUntil && copy?.uaid) {
    try { holdUntil = await fetchRolimonsHoldUntil(copy.uaid); } catch (_) { /* safe fallback */ }
  }

  const value = { holdUntil, uaid: String(uaid || copy?.uaid || "") || null };
  holdingInfoCache.set(key, { value, fetchedAt: now });
  return value;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_HOLDING_INFO") {
    fetchHoldingInfo(message)
      .then((info) => sendResponse({ ok: true, ...info }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_ROBLOX_THUMBNAILS") {
    fetchRobloxThumbnails(message.assetIds)
      .then((images) => sendResponse({ ok: true, images }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_ROLIMONS_ITEMS") {
    fetchRolimonsItems()
      .then((items) => sendResponse({ ok: true, items }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_LAST_SALE") {
    fetchLastSale(message.assetId)
      .then((salePrice) => sendResponse({ ok: true, salePrice }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_ROLIMONS_LIVE_STATS") {
    fetchLiveRolimonsStatsBatch(message.assetIds)
      .then((stats) => sendResponse({ ok: true, stats }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "RESOLVE_ROLIMONS_ITEMS") {
    resolveRolimonsItemsBatch(message.items, { fastOnly: message.fastOnly === true })
      .then((results) => sendResponse({ ok: true, results }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return false;
});

const itemPopupCache = new Map();
const ITEM_POPUP_CACHE_MS = 60 * 1000;

function decodeHtmlEntities(value) {
  return String(value || '')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>');
}

function parseNumberText(value) {
  const match = String(value || '').match(/-?[0-9][0-9,]*/);
  if (!match) return null;
  const number = Number(match[0].replace(/,/g, ''));
  return Number.isFinite(number) ? number : null;
}

function extractLabelNumber(text, label) {
  const safe = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = String(text || '').match(new RegExp(`${safe}\\s+([0-9][0-9,]*)`, 'i'));
  return match ? parseNumberText(match[1]) : null;
}

function parseSalesHistory(text) {
  const fullText = String(text || '');
  const sectionIndex = fullText.search(/Sales List/i);
  const source = sectionIndex >= 0 ? fullText.slice(sectionIndex) : fullText;
  const sales = [];

  // Rolimon's has changed the exact wording/date format of this table several
  // times. Parse each Sale Price independently instead of requiring Old RAP,
  // New RAP, and one exact timestamp format to all be present.
  const pricePattern = /Sale Price\s*(?:R\$|Robux)?\s*([0-9][0-9,]*)/gi;
  let match;
  while ((match = pricePattern.exec(source)) && sales.length < 120) {
    const price = parseNumberText(match[1]);
    if (!Number.isFinite(price)) continue;

    const contextStart = Math.max(0, match.index - 260);
    const contextEnd = Math.min(source.length, pricePattern.lastIndex + 260);
    const context = source.slice(contextStart, contextEnd);

    const dateMatch = context.match(/(20\d{2}[-\/]\d{1,2}[-\/]\d{1,2}(?:\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)?|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+20\d{2}(?:\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)?|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+20\d{2})/i);
    const oldRapMatch = context.match(/Old RAP\s*([0-9][0-9,]*)/i);
    const newRapMatch = context.match(/New RAP\s*([0-9][0-9,]*)/i);
    const parsedTime = dateMatch ? Date.parse(dateMatch[1]) : NaN;

    sales.push({
      timestamp: Number.isFinite(parsedTime) ? parsedTime : null,
      price,
      oldRap: oldRapMatch ? parseNumberText(oldRapMatch[1]) : null,
      newRap: newRapMatch ? parseNumberText(newRapMatch[1]) : null
    });
  }

  // The sales page is newest-first. Reverse it for a left-to-right history
  // graph. When timestamps cannot be parsed, use stable sequential positions.
  sales.reverse();
  let lastKnown = Date.now() - Math.max(0, sales.length - 1) * 86400000;
  for (let i = 0; i < sales.length; i++) {
    if (Number.isFinite(sales[i].timestamp)) lastKnown = sales[i].timestamp;
    else sales[i].timestamp = lastKnown + 86400000;
  }
  return sales;
}

async function fetchItemPopupData(assetId, itemName, itemRap) {
  const resolved = await resolveRolimonsItem({ assetId, name: itemName, rap: itemRap });
  if (!resolved) throw new Error("This item could not be matched in Rolimon's catalog.");
  const key = resolved.assetId;

  const now = Date.now();
  const cached = itemPopupCache.get(key);
  if (cached && now - cached.fetchedAt < ITEM_POPUP_CACHE_MS) return cached.value;

  const [salesResponse, thumbnails, exactLastSale, liveStats] = await Promise.all([
    fetch(`https://www.rolimons.com/itemsales/${encodeURIComponent(key)}`, {
      method: 'GET', credentials: 'omit', cache: 'no-store',
      headers: { Accept: 'text/html,application/xhtml+xml' }
    }),
    fetchRobloxThumbnails([key]),
    fetchLastSale(key).catch(() => null),
    fetchLiveRolimonsItemStats(key).catch(() => null)
  ]);

  const record = resolved.record;
  if (!Array.isArray(record)) throw new Error("This item could not be matched in Rolimon's catalog.");
  if (!salesResponse.ok) throw new Error(`Rolimon's sales request failed (${salesResponse.status}).`);

  const html = await salesResponse.text();
  const text = decodeHtmlEntities(htmlToText(html));
  const [name, acronym, rapRaw, valueRaw, defaultValueRaw, demandRaw, trendRaw, projectedRaw, hypedRaw, rareRaw] = record;
  const apiRap = Number(rapRaw) > 0 ? Number(rapRaw) : 0;
  // Rolimon's itemdetails index 3 is the only assigned Value field.
  // A null, -1, 0, missing, or non-numeric value means Not Assigned.
  // In that case the effective trading Value is always exactly RAP.
  const rap = apiRap;
  const effectiveValue = Number(valueRaw) > 0 ? Number(valueRaw) : rap;
  const assignedValue = Number(record?._assignedValue) > 0 ? Number(record._assignedValue) : null;
  const defaultValue = effectiveValue;
  const sales = parseSalesHistory(text);

  const result = {
    assetId: key,
    name: String(name || `Item ${key}`).trim(),
    acronym: String(acronym || '').trim(),
    rap,
    // Rolimon's trading convention: when no assigned Value exists, use RAP
    // as the effective Value shown in the popup and trade calculations.
    value: effectiveValue,
    assignedValue,
    defaultValue,
    demand: Number.isInteger(Number(liveStats?.demand)) ? Number(liveStats.demand) : Number(demandRaw),
    trend: Number.isInteger(Number(liveStats?.trend)) ? Number(liveStats.trend) : Number(trendRaw),
    projected: Number(projectedRaw) !== -1,
    hyped: Number(hypedRaw) !== -1,
    rare: Number(rareRaw) !== -1,
    bestPrice: Number(liveStats?.bestPrice) > 0
      ? Number(liveStats.bestPrice)
      : (() => {
          const parsed = extractLabelNumber(text, 'Best Price');
          return Number(parsed) > 0 ? Number(parsed) : null;
        })(),
    sellers: extractLabelNumber(text, 'Sellers'),
    pastDaySales: extractLabelNumber(text, 'Past Day Sales'),
    pastWeekSales: extractLabelNumber(text, 'Past Week Sales'),
    pastMonthSales: extractLabelNumber(text, 'Past Month Sales'),
    allTrackedSales: extractLabelNumber(text, 'All Tracked Sales'),
    lastSale: Number.isFinite(exactLastSale) ? exactLastSale : (sales.length ? sales[sales.length - 1].price : null),
    sales,
    thumbnailUrl: thumbnails?.[key] || '',
    rolimonsUrl: `https://www.rolimons.com/itemsales/${key}`,
    robloxUrl: `https://www.roblox.com/catalog/${key}`
  };

  itemPopupCache.set(key, { value: result, fetchedAt: now });
  return result;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== 'GET_ITEM_POPUP_DATA') return false;
  fetchItemPopupData(message.assetId, message.name, message.rap)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});